# Three-seed paired fine-tuning results

## Protocol

All configurations start from the official pretrained CDDFuse checkpoint. The encoder and decoder are frozen. Base and detail fusion layers are fine-tuned for 20 epochs on MSRS with learning rate `1e-5`. The plug-in configurations additionally train one module instance per branch with learning rate `1e-4`. The baseline has no plug-in. Seeds are `20261112`, `20261113`, and `20261114`; the final-epoch checkpoint is evaluated on MSRS, TNO, and RoadScene.

Metric order: EN, SD, SF, MI, SCD, VIF, Qabf, SSIMsum. The CSV files contain two-decimal values consistent with the manuscript tables; they are not unrounded intermediate tensors.

## Files

- `three_seed_per_run.csv`: 27 rows (3 methods × 3 seeds × 3 datasets).
- `three_seed_mean_std.csv`: 9 rows (3 methods × 3 datasets), mean ± sample standard deviation over seeds.
- `../CDDFuse/summarize_three_seed.py`: deterministic log parser and summary generator.

## Interpretation

For BandSplitFuse minus the same-seed baseline, MI gains are directionally consistent across all seeds: mean gains are 0.07 on MSRS, 0.05 on TNO, and 0.04 on RoadScene. VIF gains are 0.02 on TNO and 0.03 on RoadScene, and Qabf gains are 0.01 on all three datasets. SF decreases slightly on all three datasets; RoadScene SSIMsum decreases by 0.01.

The continuous variant does not show a consistent additional advantage over the original band-split design. It is retained as an explored alternative, not as the selected final model. Three seeds are insufficient for a strong significance or statistical-equivalence claim.

Raw logs, checkpoints, datasets, and generated images are intentionally excluded. To regenerate the CSV files after running the experiments, execute from the repository root:

```bash
python CDDFuse/summarize_three_seed.py
```
