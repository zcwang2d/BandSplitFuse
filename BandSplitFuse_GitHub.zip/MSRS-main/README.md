# MSRS data placement

No images or annotations are distributed in this repository.

Download MSRS from the official repository: https://github.com/Linfeng-Tang/MSRS

For training and ordinary fusion evaluation, place image pairs under:

```text
CDDFuse/MSRS_train/{ir,vi}/
CDDFuse/test_img/MSRS/{ir,vi}/
```

For the optional downstream detection evaluation, prepare the labeled subset as:

```text
MSRS-main/detection/
├── ir/          # Infrared PNG images
├── vi/          # Visible PNG images with matching filenames
└── labels/      # YOLO TXT labels with matching stems
```

Each label line must contain:

```text
class_id x_center y_center width height
```

Coordinates and dimensions are normalized to `[0, 1]`. The evaluation script maps class IDs `0`, `1`, and `2` to person, bicycle, and car. Numeric PNG filenames are expected by the default detection evaluation.

The original local protocol used 80 labeled image pairs. A different subset can be fused with `--expected-count 0`, but the evaluation script and reported protocol must then be reviewed and updated accordingly. Always comply with the dataset's original license and citation requirements.
