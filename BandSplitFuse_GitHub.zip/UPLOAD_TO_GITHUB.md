# Upload this package to GitHub

The package is a local repository directory and has not been uploaded automatically.

## 1. Final checks

```bash
python -m unittest discover -s tests -v
python -m compileall -q FourierFuse CDDFuse densefuse_pytorch-master downstream_detection tests
```

Confirm that:

- no dataset, checkpoint, log, result image, manuscript, cache, or plotting script is included;
- no local Windows username or absolute workspace path remains in the source;
- `THIRD_PARTY_NOTICES.md` has been reviewed and licensing has been resolved;
- author names, contact email, and manuscript-under-review wording are accurate;
- no fabricated DOI, model URL, or experiment result has been added.

## 2. Create an empty GitHub repository

Create a repository named `BandSplitFuse` on GitHub. To avoid conflicts during the first push, do not initialize it with a README, `.gitignore`, or license through the website.

Choose a LICENSE locally only after checking the upstream requirements in `THIRD_PARTY_NOTICES.md`.

## 3. Initialize and push

Run these commands from this package directory, replacing `<YOUR_USERNAME>` with the real GitHub account:

```bash
git init
git add .
git status
git commit -m "Initial release of BandSplitFuse research code"
git branch -M main
git remote add origin https://github.com/<YOUR_USERNAME>/BandSplitFuse.git
git push -u origin main
```

Review `git status` before committing. The supplied `.gitignore` excludes data, checkpoints, outputs, logs, environments, and caches.

## 4. Recommended repository settings

- Description: `Lightweight frequency-domain plug-and-play module for infrared and visible image fusion`
- Topics: `infrared-visible-fusion`, `image-fusion`, `frequency-domain`, `pytorch`, `cddfuse`
- Website: add only a real project or publication URL.
- Releases: upload checkpoints separately if their size and redistribution terms are suitable, then add the real links to the README.

## 5. Do not commit large experiment artifacts

Do not use `git add -f` to bypass the ignore rules for datasets or checkpoints. Large model files should be distributed through GitHub Releases or another appropriate repository only after confirming their licenses and providing checksums.
