# -*- coding: utf-8 -*-
"""Re-evaluate saved detection predictions on released MSRS test images only."""
from pathlib import Path
import argparse
import contextlib
import io
import json

import numpy as np
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval

ROOT = Path(__file__).resolve().parents[1]
METHODS = ("Visible", "Infrared", "CDDFuse", "BandSplitFuse")


def category_ap(evaluator, category_index, threshold_index=None):
    precision = evaluator.eval["precision"]
    values = (precision[:, :, category_index, 0, -1] if threshold_index is None
              else precision[threshold_index, :, category_index, 0, -1])
    valid = values[values > -1]
    return float(np.mean(valid)) if valid.size else None


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--msrs-dir", type=Path, default=ROOT / "MSRS-main",
                        help="MSRS root containing detection/ and the official test/ partition")
    parser.add_argument("--work-dir", type=Path, default=ROOT / "downstream_detection",
                        help="Directory containing msrs_detection_coco.json and predictions/*.json")
    parser.add_argument("--output", type=Path, default=None,
                        help="Output JSON; defaults to WORK_DIR/heldout_detection_results.json")
    parser.add_argument("--expected-count", type=int, default=0,
                        help="Expected held-out image count; use 23 for the manuscript protocol")
    return parser.parse_args()


def main():
    args = parse_args()
    msrs = args.msrs_dir.resolve()
    work = args.work_dir.resolve()
    output = args.output.resolve() if args.output else work / "heldout_detection_results.json"
    output.parent.mkdir(parents=True, exist_ok=True)

    test_stems = []
    for path in (msrs / "detection" / "vi").glob("*.png"):
        number = int(path.stem)
        if any((msrs / "test" / "vi" / f"{number:05d}{suffix}.png").exists()
               for suffix in ("D", "N")):
            test_stems.append(path.stem)
    test_stems.sort(key=int)
    if args.expected_count and len(test_stems) != args.expected_count:
        raise ValueError(f"Expected {args.expected_count} held-out images, found {len(test_stems)}")
    if not test_stems:
        raise ValueError("No detection images matched the released MSRS test partition")

    ground_truth_path = work / "msrs_detection_coco.json"
    ground_truth = json.loads(ground_truth_path.read_text(encoding="utf-8"))
    name_to_id = {Path(row["file_name"]).stem: row["id"] for row in ground_truth["images"]}
    image_ids = sorted(name_to_id[stem] for stem in test_stems)
    annotations = [a for a in ground_truth["annotations"] if a["image_id"] in image_ids]

    results = {}
    for method in METHODS:
        prediction_path = work / "predictions" / f"{method}.json"
        predictions = json.loads(prediction_path.read_text(encoding="utf-8"))
        filtered = [p for p in predictions if p["image_id"] in image_ids]
        filtered_path = output.parent / f"{method}_heldout_predictions.json"
        filtered_path.write_text(json.dumps(filtered), encoding="utf-8")

        coco_gt = COCO(str(ground_truth_path))
        coco_dt = coco_gt.loadRes(str(filtered_path))
        evaluator = COCOeval(coco_gt, coco_dt, "bbox")
        evaluator.params.imgIds = image_ids
        evaluator.params.catIds = [1, 2, 3]
        evaluator.params.maxDets = [1, 10, 100]
        with contextlib.redirect_stdout(io.StringIO()):
            evaluator.evaluate()
            evaluator.accumulate()
            evaluator.summarize()
        results[method] = {
            "mAP50_95": float(evaluator.stats[0]),
            "mAP50": float(evaluator.stats[1]),
            "mAP75": float(evaluator.stats[2]),
            "person_AP50_95": category_ap(evaluator, 0),
            "person_AP50": category_ap(evaluator, 0, 0),
            "car_AP50_95": category_ap(evaluator, 2),
            "car_AP50": category_ap(evaluator, 2, 0),
            "predictions": len(filtered),
        }

    metadata = {
        "protocol": "Saved predictions filtered to images explicitly present in the released MSRS test partition",
        "image_ids": image_ids,
        "file_stems": test_stems,
        "images": len(image_ids),
        "annotations": len(annotations),
        "object_counts": {
            "person": sum(a["category_id"] == 1 for a in annotations),
            "bicycle": sum(a["category_id"] == 2 for a in annotations),
            "car": sum(a["category_id"] == 3 for a in annotations),
        },
        "results": results,
    }
    output.write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(json.dumps(metadata, indent=2))
    print(f"Saved {output}")


if __name__ == "__main__":
    main()
