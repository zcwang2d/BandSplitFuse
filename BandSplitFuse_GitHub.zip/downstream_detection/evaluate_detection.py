# -*- coding: utf-8 -*-
"""Zero-shot YOLOv8n evaluation on a labeled MSRS detection subset."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import time

import numpy as np
from PIL import Image
from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
from ultralytics import YOLO
import ultralytics

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "downstream_detection"
DETECTION = ROOT / "MSRS-main" / "detection"
CLASS_NAMES = {1: "person", 2: "bicycle", 3: "car"}
METHOD_DIRS = {
    "Visible": DETECTION / "vi",
    "Infrared": DETECTION / "ir",
    "CDDFuse": WORK / "fused" / "CDDFuse",
    "BandSplitFuse": WORK / "fused" / "BandSplitFuse",
}
PARAMETERS = {"imgsz": 640, "conf": 0.001, "iou": 0.7, "max_det": 300}


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def build_ground_truth(image_paths):
    images, annotations = [], []
    annotation_id = 1
    for image_id, path in enumerate(image_paths, 1):
        with Image.open(path) as image:
            width, height = image.size
        images.append({"id": image_id, "file_name": path.name, "width": width, "height": height})
        label_path = DETECTION / "labels" / f"{path.stem}.txt"
        for line in label_path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            class_id, x_center, y_center, box_width, box_height = map(float, line.split())
            category_id = int(class_id) + 1
            width_abs, height_abs = box_width * width, box_height * height
            x_min = x_center * width - width_abs / 2
            y_min = y_center * height - height_abs / 2
            annotations.append({
                "id": annotation_id,
                "image_id": image_id,
                "category_id": category_id,
                "bbox": [x_min, y_min, width_abs, height_abs],
                "area": width_abs * height_abs,
                "iscrowd": 0,
            })
            annotation_id += 1
    categories = [{"id": key, "name": value} for key, value in CLASS_NAMES.items()]
    return {"images": images, "annotations": annotations, "categories": categories}


def predict_method(model, method, image_paths, device):
    predictions = []
    inference_ms = []
    for image_id, path in enumerate(image_paths, 1):
        with Image.open(path) as source:
            image = source.convert("RGB")
        results = model.predict(source=image, device=device, verbose=False, save=False, **PARAMETERS)
        result = results[0]
        inference_ms.append(float(sum(result.speed.values())))
        boxes = result.boxes.xyxy.cpu().numpy()
        classes = result.boxes.cls.cpu().numpy().astype(int)
        scores = result.boxes.conf.cpu().numpy()
        for box, class_id, score in zip(boxes, classes, scores):
            if class_id not in (0, 1, 2):
                continue
            x1, y1, x2, y2 = map(float, box)
            predictions.append({
                "image_id": image_id,
                "category_id": int(class_id) + 1,
                "bbox": [x1, y1, x2 - x1, y2 - y1],
                "score": float(score),
            })
        if image_id % 20 == 0:
            print(f"{method}: {image_id}/{len(image_paths)}", flush=True)
    prediction_path = WORK / "predictions" / f"{method}.json"
    prediction_path.parent.mkdir(parents=True, exist_ok=True)
    prediction_path.write_text(json.dumps(predictions), encoding="utf-8")
    return prediction_path, predictions, inference_ms


def category_ap(evaluator, category_index, threshold_index=None):
    precision = evaluator.eval["precision"]
    values = precision[:, :, category_index, 0, -1] if threshold_index is None else precision[threshold_index, :, category_index, 0, -1]
    valid = values[values > -1]
    return float(np.mean(valid)) if valid.size else None


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--weights", type=Path, default=WORK / "yolov8n.pt",
                        help="Local COCO-pretrained YOLOv8n weights")
    parser.add_argument("--device", default="0",
                        help="Ultralytics device, for example 0 or cpu")
    return parser.parse_args()


def main():
    args = parse_args()
    weights = args.weights.resolve()
    if not weights.is_file():
        raise FileNotFoundError(f"YOLOv8n weights not found: {weights}")
    started = time.time()
    image_paths = sorted((DETECTION / "ir").glob("*.png"), key=lambda p: int(p.stem))
    if not image_paths:
        raise ValueError(f"No PNG images found in {DETECTION / 'ir'}")
    ground_truth = build_ground_truth(image_paths)
    gt_path = WORK / "msrs_detection_coco.json"
    gt_path.write_text(json.dumps(ground_truth, indent=2), encoding="utf-8")
    model = YOLO(str(weights))
    summaries = {}
    for method, method_dir in METHOD_DIRS.items():
        method_paths = [method_dir / path.name for path in image_paths]
        assert all(path.exists() for path in method_paths), f"Missing images for {method}"
        prediction_path, predictions, inference_ms = predict_method(model, method, method_paths, args.device)
        coco_gt = COCO(str(gt_path))
        coco_dt = coco_gt.loadRes(str(prediction_path))
        evaluator = COCOeval(coco_gt, coco_dt, "bbox")
        evaluator.params.imgIds = list(range(1, len(image_paths) + 1))
        evaluator.params.catIds = list(CLASS_NAMES)
        evaluator.params.maxDets = [1, 10, 100]
        evaluator.evaluate()
        evaluator.accumulate()
        evaluator.summarize()
        per_class = {}
        for index, (category_id, name) in enumerate(CLASS_NAMES.items()):
            per_class[name] = {
                "AP50_95": category_ap(evaluator, index),
                "AP50": category_ap(evaluator, index, 0),
                "AP75": category_ap(evaluator, index, 5),
            }
        summaries[method] = {
            "mAP50_95": float(evaluator.stats[0]),
            "mAP50": float(evaluator.stats[1]),
            "mAP75": float(evaluator.stats[2]),
            "per_class": per_class,
            "predictions": len(predictions),
            "mean_inference_ms": float(np.mean(inference_ms)),
        }
        print(method, json.dumps(summaries[method], indent=2), flush=True)
    metadata = {
        "protocol": "Fixed COCO-pretrained YOLOv8n; no detector fine-tuning; identical parameters for all inputs",
        "detector": "YOLOv8n",
        "ultralytics_version": ultralytics.__version__,
        "weights": str(weights),
        "weights_sha256": sha256(weights),
        "parameters": PARAMETERS,
        "device": args.device,
        "images": len(image_paths),
        "annotations": len(ground_truth["annotations"]),
        "object_counts": {name: sum(a["category_id"] == key for a in ground_truth["annotations"]) for key, name in CLASS_NAMES.items()},
        "elapsed_seconds": time.time() - started,
        "results": summaries,
    }
    (WORK / "detection_results.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    with open(WORK / "detection_results.csv", "w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["Method", "mAP50_95", "mAP50", "mAP75", "Person_AP50", "Car_AP50", "Person_AP50_95", "Car_AP50_95"])
        for method, result in summaries.items():
            writer.writerow([
                method, result["mAP50_95"], result["mAP50"], result["mAP75"],
                result["per_class"]["person"]["AP50"], result["per_class"]["car"]["AP50"],
                result["per_class"]["person"]["AP50_95"], result["per_class"]["car"]["AP50_95"],
            ])
    print(f"Saved {WORK / 'detection_results.json'}", flush=True)


if __name__ == "__main__":
    main()
