import sys
import unittest
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "FourierFuse"))

from fourier_plugin import BandSplitFuse
from fourier_plugin_residual import ResidualBandSplitFuse, CircularBandSplitFuse, ResidualCircularBandSplitFuse
from fourier_plugin_continuous import ContinuousSpectralReliabilityFuse


class FineTuneVariantTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(11)
        self.ir = torch.randn(1, 8, 8, 10, requires_grad=True)
        self.vi = torch.randn(1, 8, 8, 10, requires_grad=True)

    def test_residual_variants_share_original_parameter_contract(self):
        original = BandSplitFuse(dim=8)
        for cls in (ResidualBandSplitFuse, CircularBandSplitFuse, ResidualCircularBandSplitFuse):
            with self.subTest(cls=cls.__name__):
                module = cls(dim=8)
                module.load_state_dict(original.state_dict())
                self.assertEqual(sum(p.numel() for p in module.parameters()), sum(p.numel() for p in original.parameters()))
                self.assertTrue(torch.allclose(module(self.ir, self.vi), self.ir + self.vi, atol=1e-6))

    def test_continuous_identity_weights_and_backward(self):
        module = ContinuousSpectralReliabilityFuse(dim=8)
        output, gates = module(self.ir, self.vi, return_gates=True)
        self.assertTrue(torch.allclose(output, self.ir + self.vi, atol=1e-6))
        self.assertTrue(torch.allclose(gates["w_ir"] + gates["w_vi"], torch.ones_like(gates["w_ir"])))
        self.assertEqual(sum(p.numel() for p in ContinuousSpectralReliabilityFuse(dim=64).parameters()), 20801)
        module.scale.data.fill_(0.1)
        module(self.ir, self.vi).mean().backward()
        for parameter in module.parameters():
            if parameter.grad is not None:
                self.assertTrue(torch.isfinite(parameter.grad).all())


if __name__ == "__main__":
    unittest.main()
