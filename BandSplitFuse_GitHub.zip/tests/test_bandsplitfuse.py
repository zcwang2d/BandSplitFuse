import sys
import unittest
from pathlib import Path

import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "FourierFuse"))

from fourier_plugin import BandSplitFuse, FourierFusionBlock


class BandSplitFuseTests(unittest.TestCase):
    def setUp(self):
        torch.manual_seed(7)
        self.ir = torch.randn(1, 8, 16, 32, requires_grad=True)
        self.vi = torch.randn(1, 8, 16, 32, requires_grad=True)

    def test_zero_initialized_residual_and_shape(self):
        module = BandSplitFuse(dim=8)
        output = module(self.ir, self.vi)
        self.assertEqual(output.shape, self.ir.shape)
        self.assertTrue(torch.allclose(output, self.ir + self.vi, atol=1e-6))

    def test_backward_produces_finite_gradients(self):
        module = BandSplitFuse(dim=8)
        output = module(self.ir, self.vi)
        output.square().mean().backward()
        self.assertIsNotNone(self.ir.grad)
        self.assertTrue(torch.isfinite(self.ir.grad).all())

    def test_dual_stream_block_is_identity_at_initialization(self):
        module = FourierFusionBlock(dim=8)
        out_ir, out_vi = module(self.ir, self.vi)
        self.assertTrue(torch.allclose(out_ir, self.ir, atol=1e-6))
        self.assertTrue(torch.allclose(out_vi, self.vi, atol=1e-6))


if __name__ == "__main__":
    unittest.main()
