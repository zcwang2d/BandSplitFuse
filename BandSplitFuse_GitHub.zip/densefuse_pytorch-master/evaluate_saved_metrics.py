# -*- coding: utf-8 -*-
"""分段评估已保存的 DenseFuse 图像，避免长任务中断后从头复测。"""
import importlib.util
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
CDDFUSE = os.path.join(HERE, '..', 'CDDFuse')


def load_module(name, relpath):
    spec = importlib.util.spec_from_file_location(name, os.path.join(CDDFUSE, relpath))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


Evaluator = load_module('saved_eval_evaluator', os.path.join('utils', 'Evaluator.py')).Evaluator
img_mod = load_module('saved_eval_img', os.path.join('utils', 'img_read_save.py'))
image_read_cv2 = img_mod.image_read_cv2

if len(sys.argv) != 6:
    raise SystemExit('用法: python evaluate_saved_metrics.py DATASET OUTPUT_FOLDER START END RESULT_JSON')

dataset, output_folder, start_text, end_text, result_json = sys.argv[1:]
start, end = int(start_text), int(end_text)
# Preserve caller-relative paths before switching to the CDDFuse data directory.
output_folder = os.path.abspath(output_folder)
result_json = os.path.abspath(result_json)
os.chdir(CDDFUSE)
test_folder = os.path.join('test_img', dataset)
image_names = sorted(os.listdir(os.path.join(test_folder, 'ir')))[start:end]
if not image_names:
    raise ValueError('所选图像区间为空')

metric_result = np.zeros(8)
for index, img_name in enumerate(image_names, start=1):
    ir = image_read_cv2(os.path.join(test_folder, 'ir', img_name), 'GRAY')
    vi = image_read_cv2(os.path.join(test_folder, 'vi', img_name), 'GRAY')
    fi = image_read_cv2(os.path.join(output_folder, os.path.splitext(img_name)[0] + '.png'), 'GRAY')
    metric_result += np.array([
        Evaluator.EN(fi), Evaluator.SD(fi), Evaluator.SF(fi),
        Evaluator.MI(fi, ir, vi), Evaluator.SCD(fi, ir, vi),
        Evaluator.VIFF(fi, ir, vi), Evaluator.Qabf(fi, ir, vi),
        Evaluator.SSIM(fi, ir, vi),
    ])
    if index % 20 == 0 or index == len(image_names):
        print(f'{dataset}: {index}/{len(image_names)}', flush=True)

result = {
    'dataset': dataset,
    'output_folder': output_folder,
    'start': start,
    'end': start + len(image_names),
    'count': len(image_names),
    'metric_sums': metric_result.tolist(),
    'metrics': (metric_result / len(image_names)).tolist(),
    'metric_order': ['EN', 'SD', 'SF', 'MI', 'SCD', 'VIF', 'Qabf', 'SSIM_sum'],
}
with open(result_json, 'w', encoding='utf-8') as stream:
    json.dump(result, stream, indent=2)
print(json.dumps(result, indent=2), flush=True)
