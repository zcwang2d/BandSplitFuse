# -*- coding: utf-8 -*-
"""DenseFuse 通用性测试：预训练 DenseFuse + 加法 / + BandSplitFuse 插件。

用法: python -u test_densefuse.py [插件ckpt|none] [数据集逗号分隔, 默认MSRS,TNO,RoadScene]
"""
import os
import sys
import numpy as np
import torch
import importlib.util

_HERE = os.path.dirname(os.path.abspath(__file__))
_CDDFUSE = os.path.join(_HERE, '..', 'CDDFuse')
sys.path.insert(0, os.path.join(_HERE, '..', 'FourierFuse'))

def _load(name, relpath):
    spec = importlib.util.spec_from_file_location(name, os.path.join(_CDDFUSE, relpath))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

from fourier_plugin import BandSplitFuse, count_params
from densefuse_net import DenseFuseNet
Evaluator = _load('cddf_evaluator', os.path.join('utils', 'Evaluator.py')).Evaluator
img_mod = _load('cddf_img', os.path.join('utils', 'img_read_save.py'))
img_save, image_read_cv2 = img_mod.img_save, img_mod.image_read_cv2
import warnings
warnings.filterwarnings("ignore")

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
ROOT = os.path.dirname(os.path.abspath(__file__))
os.chdir(_CDDFUSE)          # cv2.imread 不支持含中文的绝对路径, 用相对路径
TEST_IMG = 'test_img'

plugin_ckpt = sys.argv[1] if len(sys.argv) > 1 else None
if plugin_ckpt in ("none", "None", ""):
    plugin_ckpt = None
tag = "addition(原版)" if plugin_ckpt is None else os.path.basename(plugin_ckpt)
datasets = sys.argv[2].split(',') if len(sys.argv) > 2 else ["MSRS", "TNO", "RoadScene"]

device = 'cuda' if torch.cuda.is_available() else 'cpu'
model = DenseFuseNet().to(device)
model.load_state_dict(torch.load(os.path.join(ROOT, 'train_result', 'model_weight.pkl'), map_location=device)['weight'])
model.eval()

if plugin_ckpt is not None:
    # Resolve plugin paths relative to this script, not the CDDFuse data cwd.
    if not os.path.isabs(plugin_ckpt):
        plugin_ckpt = os.path.join(ROOT, plugin_ckpt)
    pck = torch.load(plugin_ckpt, map_location=device)
    _mode = pck.get('ab_mode', 'full')
    _cutoff = pck.get('cutoff', 0.125)
    Plugin = BandSplitFuse(dim=64, cutoff=_cutoff, mode=_mode).to(device)
    Plugin.load_state_dict(pck['FourierPlugin'])
    Plugin.eval()
    print(f'插件已加载: mode={_mode}, cutoff={_cutoff}, 参数量={count_params(Plugin):,}')
else:
    Plugin = None

with torch.no_grad():
    for dataset_name in datasets:
        test_folder = os.path.join(TEST_IMG, dataset_name)
        out_folder = os.path.join('..', 'densefuse_pytorch-master', 'test_result',
                                  dataset_name + ('' if Plugin is None else '_plugin'))
        os.makedirs(out_folder, exist_ok=True)
        image_names = sorted(os.listdir(os.path.join(test_folder, "ir")))
        print("\n" + "=" * 70)
        print(f"DenseFuse {tag} on {dataset_name} ({len(image_names)} pairs):")

        for img_name in image_names:
            data_IR = image_read_cv2(os.path.join(test_folder, "ir", img_name), mode='GRAY')[np.newaxis, np.newaxis, ...] / 255.0
            data_VIS = image_read_cv2(os.path.join(test_folder, "vi", img_name), mode='GRAY')[np.newaxis, np.newaxis, ...] / 255.0
            data_IR = torch.FloatTensor(data_IR).to(device)
            data_VIS = torch.FloatTensor(data_VIS).to(device)

            f_ir = model.encoder(data_IR)
            f_vi = model.encoder(data_VIS)
            fused_feat = Plugin(f_ir, f_vi) if Plugin is not None else f_ir + f_vi
            data_Fuse = model.decoder(fused_feat)
            data_min, data_max = torch.min(data_Fuse), torch.max(data_Fuse)
            data_Fuse = (data_Fuse - data_min) / (data_max - data_min).clamp_min(1e-8)
            fi = np.squeeze((data_Fuse * 255).cpu().numpy())
            img_save(fi, img_name.split(sep='.')[0], out_folder)

        metric_result = np.zeros((8))
        for img_name in image_names:
            ir = image_read_cv2(os.path.join(test_folder, "ir", img_name), 'GRAY')
            vi = image_read_cv2(os.path.join(test_folder, "vi", img_name), 'GRAY')
            fi = image_read_cv2(os.path.join(out_folder, img_name.split('.')[0] + ".png"), 'GRAY')
            metric_result += np.array([Evaluator.EN(fi), Evaluator.SD(fi),
                                       Evaluator.SF(fi), Evaluator.MI(fi, ir, vi),
                                       Evaluator.SCD(fi, ir, vi), Evaluator.VIFF(fi, ir, vi),
                                       Evaluator.Qabf(fi, ir, vi), Evaluator.SSIM(fi, ir, vi)])
        metric_result /= len(image_names)
        print("\t\t EN\t SD\t SF\t MI\tSCD\tVIF\tQabf\tSSIM")
        print("DenseFuse\t" + "\t".join(str(np.round(v, 2)) for v in metric_result))
        print("=" * 70)
