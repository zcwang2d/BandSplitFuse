# -*- coding: utf-8 -*-
"""DenseFuse + BandSplitFuse 插件训练：冻结 DenseFuse 预训练编解码器，只训练插件。

与 CDDFuse v1 同一协议（即插即用，干净归因）。零初始化起步 = 加法融合。
用法: python train_densefuse_plugin.py [epochs] [lr] [max_batches(冒烟)]
"""
import os
import sys
import time
import datetime
import importlib.util

_HERE = os.path.dirname(os.path.abspath(__file__))
_CDDFUSE = os.path.join(_HERE, '..', 'CDDFuse')
sys.path.insert(0, os.path.join(_HERE, '..', 'FourierFuse'))
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
os.environ['PYTORCH_ALLOC_CONF'] = 'expandable_segments:True'

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from fourier_plugin import BandSplitFuse, count_params
from densefuse_net import DenseFuseNet

def _load(name, relpath):
    spec = importlib.util.spec_from_file_location(name, os.path.join(_CDDFUSE, relpath))
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m

H5Dataset = _load('cddf_dataset', os.path.join('utils', 'dataset.py')).H5Dataset
Fusionloss = _load('cddf_loss', os.path.join('utils', 'loss.py')).Fusionloss

os.environ['CUDA_VISIBLE_DEVICES'] = '0'
ROOT = os.path.dirname(os.path.abspath(__file__))
os.chdir(_CDDFUSE)          # h5/cv2 对中文绝对路径兼容性差, 数据读取用相对路径

num_epochs = int(sys.argv[1]) if len(sys.argv) > 1 else 20
lr = float(sys.argv[2]) if len(sys.argv) > 2 else 1e-4
max_batches = int(sys.argv[3]) if len(sys.argv) > 3 else 0

batch_size = 2
clip_grad_norm_value = 0.01
optim_step = 8
optim_gamma = 0.5

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"device: {device}, epochs: {num_epochs}, lr: {lr}, bs: {batch_size}")

model = DenseFuseNet().to(device)
model.load_state_dict(torch.load(os.path.join(ROOT, 'train_result', 'model_weight.pkl'), map_location=device)['weight'])
for p in model.parameters():
    p.requires_grad = False
model.eval()
print("DenseFuse 预训练编解码器已加载并冻结")

Plugin = BandSplitFuse(dim=64).to(device)
Plugin.train()
print(f"插件参数量: {count_params(Plugin):,}")

criteria_fusion = Fusionloss().to(device)
optimizer = torch.optim.Adam(Plugin.parameters(), lr=lr, betas=(0.9, 0.999))
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=optim_step, gamma=optim_gamma)

trainloader = DataLoader(H5Dataset('data/MSRS_train_imgsize_128_stride_200.h5'),
                         batch_size=batch_size, shuffle=True, num_workers=0, drop_last=True)
if len(trainloader) == 0:
    raise ValueError(
        f'训练批数为 0：drop_last=True 且 batch_size={batch_size}，'
        '请增加 HDF5 图块数量或减小 batch_size。'
    )
print(f"训练批数/epoch: {len(trainloader)}")

timestamp = datetime.datetime.now().strftime("%m-%d-%H-%M")
os.makedirs(os.path.join(ROOT, 'models'), exist_ok=True)

for epoch in range(num_epochs):
    t0 = time.time()
    for i, (data_VIS, data_IR) in enumerate(trainloader):
        data_VIS = data_VIS.cuda()
        data_IR = data_IR.cuda()
        with torch.no_grad():
            f_ir = model.encoder(data_IR)
            f_vi = model.encoder(data_VIS)
        fused_feat = Plugin(f_ir, f_vi)
        # decoder 参数已冻结(requires_grad=False), 但需梯度图回传到插件, 故正常前向
        data_Fuse = model.decoder(fused_feat)

        loss, _, _ = criteria_fusion(data_VIS, data_IR, data_Fuse)
        optimizer.zero_grad()
        loss.backward()
        nn.utils.clip_grad_norm_(Plugin.parameters(), max_norm=clip_grad_norm_value, norm_type=2)
        optimizer.step()

        if max_batches > 0 and i + 1 >= max_batches:
            break
        if (i + 1) % 200 == 0 or i == 0:
            elapsed = time.time() - t0
            eta = elapsed / (i + 1) * (len(trainloader) - i - 1)
            print(f"\r[Epoch {epoch}/{num_epochs}] [Batch {i}/{len(trainloader)}] "
                  f"[fusion loss: {loss.item():.6f}] ETA: {datetime.timedelta(seconds=int(eta))}", end='')
    scheduler.step()
    ckpt = {
        'FourierPlugin': Plugin.state_dict(),
        'ab_mode': 'full', 'cutoff': 0.125, 'dual_branch': False, 'epoch': epoch,
    }
    torch.save(ckpt, os.path.join(ROOT, 'models', f'DenseFusePlugin_{timestamp}_ep{epoch}.pth'))
    print(f"\n[epoch {epoch}] saved, 显存峰值 {torch.cuda.max_memory_allocated()/1024**3:.2f} GB")

print("训练完成")
