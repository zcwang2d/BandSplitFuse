# -*- coding: utf-8 -*-
"""
FourierFusion Plugin —— 面向红外-可见图像融合的频率域即插即用模块
=================================================================

两个核心组件：

1. FourierUnit (FFC 式频域卷积单元)
   FFT -> 实部/虚部拼接 -> 1x1 卷积 -> IFFT，残差连接。
   参数量极小，提供全局感受野，弥补卷积的局部性。

2. BandSplitFuse (分频段跨模态融合单元，本文核心创新)
   物理动机：
     - 低频幅值 <-> 光照/热目标强度分布（红外占优）
     - 高频相位 <-> 边缘/纹理结构（可见光占优）
   做法：对两模态特征做 rfft2，用径向频率掩膜把频谱分成
   低/高频带；低频带用幅值门控做跨模态加权，高频带用相位
   一致性门控做加权，最后 irfft2 回空间域。

用法（插入任意双分支融合 backbone）：

    from fourier_plugin import FourierFusionBlock
    plugin = FourierFusionBlock(dim=64)          # dim = 特征通道数
    f_ir_new, f_vi_new = plugin(f_ir, f_vi)      # 插入点：特征提取之后、融合层之前
    # 或者单流网络：fused_feat = plugin.fuse(f_ir, f_vi)

依赖：PyTorch >= 1.13 (torch.fft)
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


# ----------------------------------------------------------------------
# 1. FFC 式频域单元
# ----------------------------------------------------------------------
class FourierUnit(nn.Module):
    """Spectral Transform (Fourier Unit, FFC style).

    输入输出形状均为 (B, C, H, W)。内部：
        rfft2 -> [Re; Im] 通道拼接 -> 1x1 conv -> BN -> ReLU -> 1x1 conv
        -> 拆回 Re/Im -> irfft2 -> 残差相加
    """

    def __init__(self, dim: int):
        super().__init__()
        self.conv1 = nn.Conv2d(dim * 2, dim * 2, kernel_size=1, bias=False)
        self.bn = nn.BatchNorm2d(dim * 2)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = nn.Conv2d(dim * 2, dim * 2, kernel_size=1, bias=False)
        self.scale = nn.Parameter(torch.zeros(1))  # 零初始化残差，恒等起步

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        B, C, H, W = x.shape
        # (B, C, H, W//2+1) complex
        spec = torch.fft.rfft2(x.float(), norm="ortho")
        spec = torch.stack([spec.real, spec.imag], dim=2)          # (B,C,2,H,Wf)
        spec = spec.flatten(1, 2)                                  # (B,2C,H,Wf)
        spec = self.conv2(self.relu(self.bn(self.conv1(spec))))
        spec = spec.view(B, C, 2, H, W // 2 + 1)
        out = torch.fft.irfft2(
            torch.complex(spec[:, :, 0], spec[:, :, 1]),
            s=(H, W), norm="ortho",
        )
        return x + self.scale * out.to(x.dtype)


# ----------------------------------------------------------------------
# 2. 分频段跨模态融合单元（核心创新点）
# ----------------------------------------------------------------------
def _radial_freq_mask(h: int, w: int, cutoff: float, device, dtype):
    """生成 rfft2 频谱坐标下的径向低通掩膜 (H, W//2+1)。

    cutoff ∈ (0, 0.5)：归一化截止频率（占 Nyquist 的比例）。
    """
    fy = torch.fft.fftfreq(h, device=device, dtype=dtype).view(-1, 1)   # (H,1)
    fx = torch.fft.rfftfreq(w, device=device, dtype=dtype).view(1, -1)  # (1,Wf)
    r = torch.sqrt(fx ** 2 + fy ** 2)                                   # (H,Wf)
    # 软过渡带，避免硬截断带来的振铃
    mask = torch.sigmoid((cutoff - r) / (cutoff * 0.1 + 1e-6))
    return mask                                                          # 1=低频, 0=高频


class BandSplitFuse(nn.Module):
    """分频段跨模态频率融合。

    低频带：幅值门控（热目标/光照强度，红外通常能量更高）
    高频带：相位一致性门控（纹理结构，可见光通常更可靠）

    输入:  f_ir, f_vi —— (B, C, H, W)
    输出:  fused       —— (B, C, H, W)
    """

    def __init__(self, dim: int, cutoff: float = 0.125, mode: str = 'full'):
        super().__init__()
        self.cutoff = cutoff
        assert mode in ('full', 'amp_only', 'phase_only'), mode
        self.mode = mode   # 消融：amp_only=只用低频幅值门控；phase_only=只用高频相位门控
        # 幅值门控：由两模态幅值图预测逐位置权重
        self.amp_gate = nn.Sequential(
            nn.Conv2d(dim * 2, dim, 1), nn.ReLU(inplace=True),
            nn.Conv2d(dim, dim, 1), nn.Sigmoid(),
        )
        # 相位门控：由两模态相位差预测逐位置权重
        self.pha_gate = nn.Sequential(
            nn.Conv2d(dim * 2, dim, 1), nn.ReLU(inplace=True),
            nn.Conv2d(dim, dim, 1), nn.Sigmoid(),
        )
        self.out_proj = nn.Conv2d(dim, dim, 1, bias=False)
        self.scale = nn.Parameter(torch.zeros(1))

    def forward(self, f_ir: torch.Tensor, f_vi: torch.Tensor, return_gates: bool = False):
        B, C, H, W = f_ir.shape
        S_ir = torch.fft.rfft2(f_ir.float(), norm="ortho")
        S_vi = torch.fft.rfft2(f_vi.float(), norm="ortho")

        amp_ir, amp_vi = S_ir.abs(), S_vi.abs()
        pha_ir, pha_vi = torch.angle(S_ir), torch.angle(S_vi)

        low = _radial_freq_mask(H, W, self.cutoff, f_ir.device,
                                torch.float32).unsqueeze(0).unsqueeze(0)  # (1,1,H,Wf)
        high = 1.0 - low

        # --- 低频带：幅值门控（消融 mode='phase_only' 时退化为固定均值） ---
        g_amp = None
        if self.mode == 'phase_only':
            amp_low = (amp_ir + amp_vi) * 0.5
            pha_low = (pha_ir + pha_vi) * 0.5
        else:
            g_amp = self.amp_gate(torch.cat([
                torch.log1p(amp_ir), torch.log1p(amp_vi)], dim=1))            # (B,C,H,Wf)
            amp_low = g_amp * amp_ir + (1 - g_amp) * amp_vi
            pha_low = g_amp * pha_ir + (1 - g_amp) * pha_vi

        # --- 高频带：相位差门控（消融 mode='amp_only' 时退化为固定均值） ---
        g_pha = None
        if self.mode == 'amp_only':
            amp_high = (amp_ir + amp_vi) * 0.5
            pha_high = (pha_ir + pha_vi) * 0.5
        else:
            dpha = torch.abs(torch.atan2(torch.sin(pha_ir - pha_vi),
                                         torch.cos(pha_ir - pha_vi)))         # (B,C,H,Wf)
            g_pha = self.pha_gate(torch.cat([dpha, torch.log1p(amp_vi)], dim=1))
            amp_high = g_pha * amp_vi + (1 - g_pha) * (amp_ir + amp_vi) * 0.5
            pha_high = g_pha * pha_vi + (1 - g_pha) * (pha_ir + pha_vi) * 0.5

        # --- 分频段重组 ---
        amp = low * amp_low + high * amp_high
        pha = low * pha_low + high * pha_high
        spec = torch.polar(amp, pha)
        fused = torch.fft.irfft2(spec, s=(H, W), norm="ortho")
        fused = self.out_proj(fused.to(f_ir.dtype))

        # 残差：以两模态特征之和作为基底（与 CDDFuse 等 backbone 的加法融合约定一致）
        base = f_ir + f_vi
        out = base + self.scale * fused
        if return_gates:
            return out, {'g_amp': g_amp, 'g_pha': g_pha, 'low_mask': low}
        return out


# ----------------------------------------------------------------------
# 3. 即插即用组合块
# ----------------------------------------------------------------------
class FourierFusionBlock(nn.Module):
    """即插即用融合块 = 每模态一个 FourierUnit + 一个 BandSplitFuse。

    插入方式（双流 backbone）：
        f_ir, f_vi = backbone.encoders(ir, vi)
        f_ir, f_vi = plugin(f_ir, f_vi)          # <== 就这一行
        out = backbone.fusion(f_ir, f_vi)
    """

    def __init__(self, dim: int, cutoff: float = 0.125):
        super().__init__()
        self.fu_ir = FourierUnit(dim)
        self.fu_vi = FourierUnit(dim)
        self.fuse_unit = BandSplitFuse(dim, cutoff)
        self.mix = nn.Conv2d(dim * 2, dim * 2, 1, bias=False)
        nn.init.zeros_(self.mix.weight)  # 恒等起步

    def forward(self, f_ir: torch.Tensor, f_vi: torch.Tensor):
        f_ir = self.fu_ir(f_ir)
        f_vi = self.fu_vi(f_vi)
        fused = self.fuse_unit(f_ir, f_vi)
        delta = self.mix(torch.cat([fused, fused], dim=1))
        d_ir, d_vi = delta.chunk(2, dim=1)
        return f_ir + d_ir, f_vi + d_vi

    def fuse(self, f_ir: torch.Tensor, f_vi: torch.Tensor) -> torch.Tensor:
        """单流用法：直接返回融合特征。"""
        return self.fuse_unit(self.fu_ir(f_ir), self.fu_vi(f_vi))


def count_params(m: nn.Module) -> int:
    return sum(p.numel() for p in m.parameters())
