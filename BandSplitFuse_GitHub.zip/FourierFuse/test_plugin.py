# -*- coding: utf-8 -*-
"""FourierFusion 插件模块自检脚本。

用法：
    python test_plugin.py            # CPU 快速自检
    python test_plugin.py --cuda     # GPU 自检（含 amp 半精度）

检查项：
1. 各模块输入输出形状一致性
2. 参数量统计（验证"插件仅增 0.X% 参数"的论文叙事）
3. 零初始化 => 初始状态等价于恒等/均值融合（训练稳定性）
4. 反向传播梯度流正常
"""
import argparse
import torch

from fourier_plugin import FourierUnit, BandSplitFuse, FourierFusionBlock, count_params


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cuda", action="store_true")
    args = parser.parse_args()

    device = "cuda" if args.cuda and torch.cuda.is_available() else "cpu"
    if device == "cuda":
        print(f"GPU: {torch.cuda.get_device_name(0)}, "
              f"capability={torch.cuda.get_device_capability(0)}")

    B, C, H, W = 2, 64, 128, 128
    f_ir = torch.randn(B, C, H, W, device=device, requires_grad=True)
    f_vi = torch.randn(B, C, H, W, device=device, requires_grad=True)

    # --- 1. FourierUnit ---
    fu = FourierUnit(C).to(device)
    out = fu(f_ir)
    assert out.shape == f_ir.shape, f"FourierUnit shape mismatch: {out.shape}"
    print(f"[OK] FourierUnit      shape {tuple(out.shape)}, params={count_params(fu):,}")

    # --- 2. BandSplitFuse ---
    bsf = BandSplitFuse(C).to(device)
    fused = bsf(f_ir, f_vi)
    assert fused.shape == f_ir.shape, f"BandSplitFuse shape mismatch: {fused.shape}"
    print(f"[OK] BandSplitFuse    shape {tuple(fused.shape)}, params={count_params(bsf):,}")

    # --- 3. FourierFusionBlock ---
    blk = FourierFusionBlock(C).to(device)
    o_ir, o_vi = blk(f_ir, f_vi)
    assert o_ir.shape == f_ir.shape and o_vi.shape == f_vi.shape
    print(f"[OK] FusionBlock      shapes {tuple(o_ir.shape)}/{tuple(o_vi.shape)}, "
          f"params={count_params(blk):,}")

    # --- 4. 零初始化恒等性 ---
    # scale=0 且 mix 权重为 0 => 输出应等于输入
    assert torch.allclose(o_ir, f_ir.detach() + 0, atol=1e-5), \
        "block should be identity at init (dual-stream path)"
    print("[OK] 零初始化恒等性    dual-stream 输出 == 输入（训练初期不破坏 backbone）")

    # --- 5. 反向传播 ---
    loss = (o_ir.sum() + o_vi.sum() + fused.square().mean())
    loss.backward()
    assert f_ir.grad is not None and torch.isfinite(f_ir.grad).all()
    print("[OK] 反向传播          梯度有限且到达输入")

    # --- 6. 与典型 backbone 的参数量对比（叙事素材） ---
    toy_backbone = torch.nn.Sequential(
        *[torch.nn.Conv2d(C, C, 3, padding=1) for _ in range(8)]
    ).to(device)
    n_bb, n_pl = count_params(toy_backbone), count_params(blk)
    print(f"[INFO] 8层CNN模拟backbone: {n_bb:,} params, "
          f"插件: {n_pl:,} params ({100*n_pl/n_bb:.2f}%)")

    print("\n全部自检通过 ✅")


if __name__ == "__main__":
    main()
