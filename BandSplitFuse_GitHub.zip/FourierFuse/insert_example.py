# -*- coding: utf-8 -*-
"""示例：把 FourierFusionBlock 插入现有融合 backbone。

以"双分支编码器 + 融合层"的典型结构为例（CDDFuse / SwinFusion 同构）。
实际接入开源仓库时只需三步：
    1. from fourier_plugin import FourierFusionBlock
    2. 在 backbone 的 __init__ 里加一行：self.plugin = FourierFusionBlock(dim)
    3. 在 forward 的特征提取之后、融合之前加一行：f_ir, f_vi = self.plugin(f_ir, f_vi)
"""
import torch
import torch.nn as nn

from fourier_plugin import FourierFusionBlock, count_params


class ToyBackbone(nn.Module):
    """模拟典型双流融合 backbone（替换成 CDDFuse 等真实结构即可）。"""

    def __init__(self, dim: int = 64, use_plugin: bool = False):
        super().__init__()
        self.enc_ir = nn.Sequential(nn.Conv2d(1, dim, 3, padding=1), nn.ReLU(inplace=True))
        self.enc_vi = nn.Sequential(nn.Conv2d(1, dim, 3, padding=1), nn.ReLU(inplace=True))
        self.plugin = FourierFusionBlock(dim) if use_plugin else None
        self.fusion = nn.Sequential(
            nn.Conv2d(dim * 2, dim, 3, padding=1), nn.ReLU(inplace=True),
            nn.Conv2d(dim, 1, 3, padding=1), nn.Sigmoid(),
        )

    def forward(self, ir: torch.Tensor, vi: torch.Tensor) -> torch.Tensor:
        f_ir, f_vi = self.enc_ir(ir), self.enc_vi(vi)
        if self.plugin is not None:                      # <== 插入点就这一处
            f_ir, f_vi = self.plugin(f_ir, f_vi)
        return self.fusion(torch.cat([f_ir, f_vi], dim=1))


if __name__ == "__main__":
    device = "cuda" if torch.cuda.is_available() else "cpu"
    ir = torch.rand(2, 1, 256, 256, device=device)
    vi = torch.rand(2, 1, 256, 256, device=device)

    base = ToyBackbone(use_plugin=False).to(device)
    plug = ToyBackbone(use_plugin=True).to(device)

    out_b, out_p = base(ir, vi), plug(ir, vi)
    print(f"baseline 输出: {tuple(out_b.shape)}, params={count_params(base):,}")
    print(f"plugin   输出: {tuple(out_p.shape)}, params={count_params(plug):,}")
    delta = count_params(plug) - count_params(base)
    print(f"插件新增参数: {delta:,} ({100 * delta / count_params(base):.2f}%)")
