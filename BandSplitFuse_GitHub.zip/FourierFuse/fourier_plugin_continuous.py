# -*- coding: utf-8 -*-
"""Continuous spectral reliability routing for infrared-visible feature fusion.

The module removes the fixed low/high-band assumption.  Per-frequency modality
weights are predicted from spectral energy, phase coherence, and normalized
radial frequency.  Fusion is performed directly on complex spectra and the
learned correction starts from the host's native additive fusion.
"""
import torch
import torch.nn as nn


class ContinuousSpectralReliabilityFuse(nn.Module):
    """Content-adaptive two-modal complex-spectrum routing with identity start."""

    def __init__(self, dim: int):
        super().__init__()
        self.dim = dim
        self.reliability = nn.Sequential(
            nn.Conv2d(dim * 2 + 2, dim, kernel_size=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(dim, dim * 2, kernel_size=1),
        )
        # Start with equal modality weights; learning then breaks the symmetry.
        nn.init.zeros_(self.reliability[-1].weight)
        nn.init.zeros_(self.reliability[-1].bias)
        self.out_proj = nn.Conv2d(dim, dim, kernel_size=1, bias=False)
        self.scale = nn.Parameter(torch.zeros(1))

    def forward(self, f_ir: torch.Tensor, f_vi: torch.Tensor, return_gates: bool = False):
        batch, channels, height, width = f_ir.shape
        if channels != self.dim:
            raise ValueError(f"expected {self.dim} channels, received {channels}")
        spec_ir = torch.fft.rfft2(f_ir.float(), norm="ortho")
        spec_vi = torch.fft.rfft2(f_vi.float(), norm="ortho")
        amp_ir, amp_vi = spec_ir.abs(), spec_vi.abs()

        phase_coherence = torch.cos(torch.angle(spec_ir) - torch.angle(spec_vi)).mean(
            dim=1, keepdim=True
        )
        fy = torch.fft.fftfreq(height, device=f_ir.device, dtype=torch.float32).view(-1, 1)
        fx = torch.fft.rfftfreq(width, device=f_ir.device, dtype=torch.float32).view(1, -1)
        radial = torch.sqrt(fx.square() + fy.square()).div(0.5).clamp(0.0, 1.0)
        radial = radial.view(1, 1, height, -1).expand(batch, 1, -1, -1)
        reliability_input = torch.cat([
            torch.log1p(amp_ir), torch.log1p(amp_vi), phase_coherence, radial
        ], dim=1)
        modality_weights = self.reliability(reliability_input)
        modality_weights = modality_weights.view(batch, 2, channels, height, -1)
        modality_weights = torch.softmax(modality_weights, dim=1)

        fused_spectrum = (
            modality_weights[:, 0] * spec_ir + modality_weights[:, 1] * spec_vi
        )
        fused = torch.fft.irfft2(fused_spectrum, s=(height, width), norm="ortho")
        fused = self.out_proj(fused.to(f_ir.dtype))
        base = f_ir + f_vi
        out = base + self.scale * (fused - base)
        if return_gates:
            return out, {
                "w_ir": modality_weights[:, 0],
                "w_vi": modality_weights[:, 1],
                "phase_coherence": phase_coherence,
            }
        return out


def count_params(module: nn.Module) -> int:
    return sum(parameter.numel() for parameter in module.parameters())
