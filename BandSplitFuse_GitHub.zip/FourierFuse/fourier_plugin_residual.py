# -*- coding: utf-8 -*-
"""Residual, circular-phase candidate for controlled post-hoc optimization.

This file intentionally leaves the original BandSplitFuse untouched.  The
candidate has exactly the same trainable parameters and differs only in:
1. zero-initialized residual correction of the native additive fusion;
2. weighted unit-phasor averaging instead of direct angle averaging.
"""
import torch

from fourier_plugin import BandSplitFuse, _radial_freq_mask


class ResidualCircularBandSplitFuse(BandSplitFuse):
    """Combined candidate; class flags preserve its original experiment."""

    use_circular_phase = True
    use_delta_residual = True
    use_candidate_high_amp = True

    @staticmethod
    def _circular_average(pha_first, pha_second, weight_first):
        """Circular weighted mean; weight_first selects the first input."""
        z_first = torch.polar(torch.ones_like(pha_first), pha_first)
        z_second = torch.polar(torch.ones_like(pha_second), pha_second)
        z_mean = weight_first * z_first + (1.0 - weight_first) * z_second
        return torch.angle(z_mean)

    def forward(self, f_ir: torch.Tensor, f_vi: torch.Tensor, return_gates: bool = False):
        _, _, height, width = f_ir.shape
        spec_ir = torch.fft.rfft2(f_ir.float(), norm="ortho")
        spec_vi = torch.fft.rfft2(f_vi.float(), norm="ortho")
        amp_ir, amp_vi = spec_ir.abs(), spec_vi.abs()
        pha_ir, pha_vi = torch.angle(spec_ir), torch.angle(spec_vi)

        low = _radial_freq_mask(
            height, width, self.cutoff, f_ir.device, torch.float32
        ).unsqueeze(0).unsqueeze(0)
        high = 1.0 - low

        g_amp = None
        if self.mode == "phase_only":
            g_low = torch.full_like(amp_ir, 0.5)
        else:
            g_amp = self.amp_gate(torch.cat([
                torch.log1p(amp_ir), torch.log1p(amp_vi)
            ], dim=1))
            g_low = g_amp
        amp_low = g_low * amp_ir + (1.0 - g_low) * amp_vi
        if self.use_circular_phase:
            pha_low = self._circular_average(pha_ir, pha_vi, g_low)
        else:
            pha_low = g_low * pha_ir + (1.0 - g_low) * pha_vi

        g_pha = None
        if self.mode == "amp_only":
            g_high = torch.full_like(amp_ir, 0.5)
        else:
            delta_phase = torch.abs(torch.atan2(
                torch.sin(pha_ir - pha_vi), torch.cos(pha_ir - pha_vi)
            ))
            g_pha = self.pha_gate(torch.cat([
                delta_phase, torch.log1p(amp_vi)
            ], dim=1))
            g_high = g_pha
        if self.use_candidate_high_amp:
            amp_high = g_high * amp_vi + (1.0 - g_high) * amp_ir
        else:
            amp_high = g_high * amp_vi + (1.0 - g_high) * (amp_ir + amp_vi) * 0.5
        if self.use_circular_phase:
            pha_high = self._circular_average(pha_vi, pha_ir, g_high)
        else:
            pha_high = g_high * pha_vi + (1.0 - g_high) * (pha_ir + pha_vi) * 0.5

        amplitude = low * amp_low + high * amp_high
        phase = low * pha_low + high * pha_high
        fused = torch.fft.irfft2(
            torch.polar(amplitude, phase), s=(height, width), norm="ortho"
        )
        fused = self.out_proj(fused.to(f_ir.dtype))

        base = f_ir + f_vi
        correction = fused - base if self.use_delta_residual else fused
        out = base + self.scale * correction
        if return_gates:
            return out, {"g_amp": g_amp, "g_pha": g_pha, "low_mask": low}
        return out


class ResidualBandSplitFuse(ResidualCircularBandSplitFuse):
    """Only the delta residual differs from the original spectral plug-in."""

    use_circular_phase = False
    use_delta_residual = True
    use_candidate_high_amp = False


class CircularBandSplitFuse(ResidualCircularBandSplitFuse):
    """Only circular phase averaging differs from the original spectral plug-in."""

    use_circular_phase = True
    use_delta_residual = False
    use_candidate_high_amp = False
