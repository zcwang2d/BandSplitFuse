import numpy as np
import cv2
import os
from skimage.io import imsave

def image_read_cv2(path, mode='RGB'):
    # imdecode + fromfile supports Unicode paths on Windows and POSIX.
    path = os.fspath(path)
    encoded = np.fromfile(path, dtype=np.uint8)
    img_BGR = cv2.imdecode(encoded, cv2.IMREAD_COLOR)
    if img_BGR is None:
        raise FileNotFoundError(f'Cannot decode image: {path}')
    img_BGR = img_BGR.astype('float32')
    assert mode == 'RGB' or mode == 'GRAY' or mode == 'YCrCb', 'mode error'
    if mode == 'RGB':
        img = cv2.cvtColor(img_BGR, cv2.COLOR_BGR2RGB)
    elif mode == 'GRAY':  
        img = np.round(cv2.cvtColor(img_BGR, cv2.COLOR_BGR2GRAY))
    elif mode == 'YCrCb':
        img = cv2.cvtColor(img_BGR, cv2.COLOR_BGR2YCrCb)
    return img

def img_save(image,imagename,savepath):
    if not os.path.exists(savepath):
        os.makedirs(savepath)
    # Gray_pic（新版 imageio/pillow 不接受 float 数组，需转 uint8）
    imsave(os.path.join(savepath, "{}.png".format(imagename)),
           np.clip(image, 0, 255).astype('uint8'), check_contrast=False)