# -*- coding: utf-8 -*-
"""Paired multi-seed validation for baseline, original, and continuous-routing variants."""
from pathlib import Path
import datetime
import glob
import json
import os
import subprocess
import sys

HERE = Path(__file__).resolve().parent
OUT = HERE / "controlled_experiments_20261112"
STATUS = OUT / "continuous_multiseed_queue_status.json"
# Interleave paired methods per seed for a consistent queue.
CONFIGS = [
    (seed, mode, variant)
    for seed in (20261113, 20261114)
    for mode, variant in (("baseline", "original"), ("full", "original"), ("full", "continuous_reliability"))
]


def now():
    return datetime.datetime.now().isoformat(timespec="seconds")


def write_status(state):
    STATUS.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


def final_checkpoint(mode, variant, seed):
    run_mode = mode if variant == "original" else f"{mode}_{variant}"
    files = glob.glob(str(HERE / "models" / f"CDDFuse_finetune_{run_mode}_seed{seed}_*_ep19.pth"))
    return max(files, key=os.path.getmtime) if files else None


state = {
    "status": "running",
    "created_at": now(),
    "configs": [],
    "note": "Three-way paired validation; seed 20261112 is complete; seeds 20261113/20261114 are queued here.",
}
write_status(state)
for seed, mode, variant in CONFIGS:
    run_mode = mode if variant == "original" else f"{mode}_{variant}"
    tag = f"finetune_{run_mode}_seed{seed}"
    entry = {"tag": tag, "mode": mode, "variant": variant, "seed": seed, "status": "running", "started_at": now()}
    state["current"] = tag
    state["configs"] = [item for item in state["configs"] if item["tag"] != tag] + [entry]
    write_status(state)
    checkpoint = final_checkpoint(mode, variant, seed)
    if checkpoint is None:
        train_log = OUT / f"train_{tag}.log"
        with train_log.open("a", encoding="utf-8") as stream:
            stream.write(f"\n\n=== run {now()} ===\n")
            stream.flush()
            result = subprocess.run(
                [sys.executable, "-u", "train_fusion_finetune.py", "--mode", mode,
                 "--plugin-variant", variant, "--seed", str(seed), "--epochs", "20"],
                cwd=HERE, stdout=stream, stderr=subprocess.STDOUT,
            )
        entry["train_returncode"] = result.returncode
        if result.returncode != 0:
            entry["status"] = "failed_training"
            state["status"] = "failed"
            write_status(state)
            sys.exit(result.returncode)
        checkpoint = final_checkpoint(mode, variant, seed)
    if checkpoint is None:
        entry["status"] = "missing_final_checkpoint"
        state["status"] = "failed"
        write_status(state)
        sys.exit(2)

    entry["checkpoint"] = checkpoint
    test_log = OUT / f"test_{tag}.log"
    with test_log.open("w", encoding="utf-8") as stream:
        result = subprocess.run(
            [sys.executable, "-u", "test_fusion_finetune.py", checkpoint, "MSRS,TNO,RoadScene"],
            cwd=HERE, stdout=stream, stderr=subprocess.STDOUT,
        )
    entry["test_returncode"] = result.returncode
    if result.returncode != 0:
        entry["status"] = "failed_testing"
        state["status"] = "failed"
        write_status(state)
        sys.exit(result.returncode)
    entry["status"] = "completed"
    entry["completed_at"] = now()
    state["configs"] = [item for item in state["configs"] if item["tag"] != tag] + [entry]
    write_status(state)

state["status"] = "completed"
state["current"] = None
state["completed_at"] = now()
write_status(state)
print("CONTINUOUS_MULTISEED_DONE", flush=True)
