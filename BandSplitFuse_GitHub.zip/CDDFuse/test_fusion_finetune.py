# -*- coding: utf-8 -*-
"""Evaluate fine-tuned CDDFuse checkpoints with optional dual-branch plug-ins."""
from pathlib import Path
import os
import sys

import numpy as np
import torch
import torch.nn as nn

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "FourierFuse"))
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
from fourier_plugin import BandSplitFuse
from fourier_plugin_residual import ResidualBandSplitFuse, CircularBandSplitFuse, ResidualCircularBandSplitFuse
from fourier_plugin_continuous import ContinuousSpectralReliabilityFuse
from net import Restormer_Encoder, Restormer_Decoder, BaseFeatureExtraction, DetailFeatureExtraction
from utils.Evaluator import Evaluator
from utils.img_read_save import img_save, image_read_cv2

PLUGIN_CLASSES = {
    "original": BandSplitFuse,
    "residual_only": ResidualBandSplitFuse,
    "circular_only": CircularBandSplitFuse,
    "residual_circular": ResidualCircularBandSplitFuse,
    "continuous_reliability": ContinuousSpectralReliabilityFuse,
}


def main():
    if len(sys.argv) < 2:
        raise SystemExit("usage: test_fusion_finetune.py CHECKPOINT [MSRS,TNO,RoadScene]")
    checkpoint_path = Path(sys.argv[1])
    datasets = sys.argv[2].split(",") if len(sys.argv) > 2 else ["MSRS", "TNO", "RoadScene"]
    device = "cuda" if torch.cuda.is_available() else "cpu"
    checkpoint = torch.load(checkpoint_path, map_location=device)
    use_plugin = bool(checkpoint.get("use_plugin", False))
    plugin_variant = checkpoint.get("plugin_variant", "original")
    plugin_class = PLUGIN_CLASSES[plugin_variant]

    Encoder = nn.DataParallel(Restormer_Encoder()).to(device)
    Decoder = nn.DataParallel(Restormer_Decoder()).to(device)
    BaseFuseLayer = nn.DataParallel(BaseFeatureExtraction(dim=64, num_heads=8)).to(device)
    DetailFuseLayer = nn.DataParallel(DetailFeatureExtraction(num_layers=1)).to(device)
    Encoder.load_state_dict(checkpoint["CDDF_Encoder"])
    Decoder.load_state_dict(checkpoint["CDDF_Decoder"])
    BaseFuseLayer.load_state_dict(checkpoint["BaseFuseLayer"])
    DetailFuseLayer.load_state_dict(checkpoint["DetailFuseLayer"])
    if use_plugin:
        plugin_kwargs = {} if plugin_variant == "continuous_reliability" else {"cutoff": checkpoint.get("cutoff", 0.125)}
        Plugin_B = nn.DataParallel(plugin_class(dim=64, **plugin_kwargs)).to(device)
        Plugin_D = nn.DataParallel(plugin_class(dim=64, **plugin_kwargs)).to(device)
        Plugin_B.load_state_dict(checkpoint["FourierPlugin"])
        Plugin_D.load_state_dict(checkpoint["FourierPlugin_D"])
    else:
        Plugin_B = Plugin_D = None
    modules = [Encoder, Decoder, BaseFuseLayer, DetailFuseLayer] + ([Plugin_B, Plugin_D] if use_plugin else [])
    for module in modules:
        module.eval()

    tag = checkpoint_path.stem
    for dataset in datasets:
        print("\n" + "=" * 80)
        print(f"Fine-tune evaluation: {dataset}; checkpoint={tag}; plugin={use_plugin}")
        test_folder = Path("test_img") / dataset
        out_folder = Path("controlled_experiments_20261112") / "finetune_outputs" / tag / dataset
        out_folder.mkdir(parents=True, exist_ok=True)
        image_names = sorted(os.listdir(test_folder / "ir"))
        with torch.no_grad():
            for image_name in image_names:
                ir = image_read_cv2(str(test_folder / "ir" / image_name), mode="GRAY")[np.newaxis, np.newaxis, ...] / 255.0
                vi = image_read_cv2(str(test_folder / "vi" / image_name), mode="GRAY")[np.newaxis, np.newaxis, ...] / 255.0
                ir = torch.FloatTensor(ir).to(device)
                vi = torch.FloatTensor(vi).to(device)
                feature_V_B, feature_V_D, _ = Encoder(vi)
                feature_I_B, feature_I_D, _ = Encoder(ir)
                if use_plugin:
                    fused_B = Plugin_B(feature_I_B, feature_V_B)
                    fused_D = Plugin_D(feature_I_D, feature_V_D)
                else:
                    fused_B = feature_I_B + feature_V_B
                    fused_D = feature_I_D + feature_V_D
                data_Fuse, _ = Decoder(vi, BaseFuseLayer(fused_B), DetailFuseLayer(fused_D))
                data_min, data_max = torch.min(data_Fuse), torch.max(data_Fuse)
                data_Fuse = (data_Fuse - data_min) / (data_max - data_min).clamp_min(1e-8)
                output = np.squeeze((data_Fuse * 255).cpu().numpy())
                img_save(output, os.path.splitext(image_name)[0], str(out_folder))

        metric_result = np.zeros(8)
        for image_name in image_names:
            ir = image_read_cv2(str(test_folder / "ir" / image_name), "GRAY")
            vi = image_read_cv2(str(test_folder / "vi" / image_name), "GRAY")
            fi = image_read_cv2(str(out_folder / (os.path.splitext(image_name)[0] + ".png")), "GRAY")
            metric_result += np.array([
                Evaluator.EN(fi), Evaluator.SD(fi), Evaluator.SF(fi),
                Evaluator.MI(fi, ir, vi), Evaluator.SCD(fi, ir, vi),
                Evaluator.VIFF(fi, ir, vi), Evaluator.Qabf(fi, ir, vi),
                Evaluator.SSIM(fi, ir, vi),
            ])
        metric_result /= len(image_names)
        print("\t\t EN\t SD\t SF\t MI\tSCD\tVIF\tQabf\tSSIM")
        print("FineTune\t" + "\t".join(str(np.round(value, 2)) for value in metric_result), flush=True)


if __name__ == "__main__":
    os.chdir(HERE)
    main()
