# -*- coding: utf-8 -*-
"""严格受控消融：从同一官方基线独立训练并测试 4 个配置。

所有配置均冻结整个 CDDFuse 骨干（包括两个融合层），仅训练插件 20 epoch，
使用原始 Fusionloss，固定相同随机种子；不再从 v2 热启动或沿用旧消融结果。
结果写入 corrected_ablation_results.txt，历史文件保持不变。

用法：python run_ablation.py
"""
import glob
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
PY = sys.executable
RESULTS = os.path.join(HERE, "corrected_ablation_results.txt")

CONFIGS = [
    ("amp_only",   0.125),
    ("phase_only", 0.125),
    ("full",       0.0625),
    ("full",       0.25),
]


def latest_ckpt(mode, cutoff):
    pat = os.path.join(HERE, "models", f"CDDFuse_pnpAb_{mode}_c{cutoff}_*_ep19.pth")
    files = glob.glob(pat)
    return max(files, key=os.path.getmtime) if files else None


with open(RESULTS, "a", encoding="utf-8") as fout:
    for mode, cutoff in CONFIGS:
        tag = f"{mode}_c{cutoff}"
        train_log = os.path.join(HERE, f"corrected_ablation_train_{tag}.log")
        test_log = os.path.join(HERE, f"corrected_ablation_test_{tag}.log")
        fout.write(f"\n{'='*70}\n[配置 {tag}] 开始 {time.strftime('%H:%M:%S')}\n")
        fout.flush()

        ckpt = latest_ckpt(mode, cutoff)
        if ckpt is None:
            t0 = time.time()
            with open(train_log, "w", encoding="utf-8") as lf:
                result = subprocess.run(
                    [PY, "-u", "train_plugin_ablation.py", "20", "1e-4", "0", mode, str(cutoff)],
                    cwd=HERE, stdout=lf, stderr=subprocess.STDOUT)
            if result.returncode != 0:
                fout.write(f"[配置 {tag}] 训练失败！见 {os.path.basename(train_log)}\n")
                fout.flush()
                continue
            ckpt = latest_ckpt(mode, cutoff)
            fout.write(f"[配置 {tag}] 训练完成，耗时 {(time.time()-t0)/60:.0f} 分钟，"
                       f"ckpt={os.path.basename(ckpt)}\n")
        else:
            fout.write(f"[配置 {tag}] 已存在修正后结果，跳过训练: {os.path.basename(ckpt)}\n")
        fout.flush()

        t0 = time.time()
        with open(test_log, "w", encoding="utf-8") as lf:
            result = subprocess.run(
                [PY, "-u", "test_IVF_plugin.py", ckpt, "MSRS,TNO,RoadScene"],
                cwd=HERE, stdout=lf, stderr=subprocess.STDOUT)
        fout.write(f"[配置 {tag}] 测试完成，耗时 {(time.time()-t0)/60:.0f} 分钟，"
                   f"返回码 {result.returncode}\n")
        try:
            with open(test_log, encoding="utf-8", errors="ignore") as lf:
                for line in lf:
                    if "CDDFuse+Plugin" in line and "\t" in line:
                        fout.write("  指标: " + line.strip() + "\n")
        except Exception as exc:
            fout.write(f"  指标提取失败: {exc}\n")
        fout.flush()

    fout.write(f"\n全部修正后消融实验完成 {time.strftime('%H:%M:%S')}\n")

print("ALL DONE，结果见 corrected_ablation_results.txt")
