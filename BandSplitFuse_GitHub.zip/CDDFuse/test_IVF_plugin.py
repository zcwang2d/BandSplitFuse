# -*- coding: utf-8 -*-
"""CDDFuse + FourierFusion 插件 联合推理测试。

在预训练 CDDFuse 上插入零初始化的 BandSplitFuse（作用于 base 低频特征），
由于插件零初始化（输出 = V_B + I_B，与原始加法完全一致），
融合结果和指标应与原版完全相同 —— 以此验证插件可无缝插入。

用法：python test_IVF_plugin.py [插件权重路径（可选，不填则零初始化）]
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'FourierFuse'))
from fourier_plugin import BandSplitFuse, count_params

from net import Restormer_Encoder, Restormer_Decoder, BaseFeatureExtraction, DetailFeatureExtraction
import numpy as np
from utils.Evaluator import Evaluator
import torch
import torch.nn as nn
from utils.img_read_save import img_save, image_read_cv2
import warnings
import logging
warnings.filterwarnings("ignore")
logging.basicConfig(level=logging.CRITICAL)

os.environ["CUDA_VISIBLE_DEVICES"] = "0"
ckpt_path = r"models/CDDFuse_IVF.pth"
plugin_ckpt = sys.argv[1] if len(sys.argv) > 1 else None
if plugin_ckpt in ("none", "None", ""):
    plugin_ckpt = None
tag = "零初始化" if plugin_ckpt is None else os.path.basename(plugin_ckpt)

for dataset_name in (sys.argv[2].split(',') if len(sys.argv) > 2 else ["TNO", "RoadScene"]):
    print("\n" * 2 + "=" * 80)
    print("The test result of " + dataset_name + ' (CDDFuse + FourierPlugin, ' + tag + '):')
    test_folder = os.path.join('test_img', dataset_name)
    test_out_folder = os.path.join('test_result_plugin', dataset_name)

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    Encoder = nn.DataParallel(Restormer_Encoder()).to(device)
    Decoder = nn.DataParallel(Restormer_Decoder()).to(device)
    BaseFuseLayer = nn.DataParallel(BaseFeatureExtraction(dim=64, num_heads=8)).to(device)
    DetailFuseLayer = nn.DataParallel(DetailFeatureExtraction(num_layers=1)).to(device)
    # 若 checkpoint 记录了消融配置，按其构造插件（保证前向行为一致）
    _mode, _cutoff, _dual = 'full', 0.125, False
    if plugin_ckpt is not None:
        _pck = torch.load(plugin_ckpt, map_location=device)
        _mode = _pck.get('ab_mode', 'full')
        _cutoff = _pck.get('cutoff', 0.125)
        _dual = bool(_pck.get('dual_branch', False))
    Plugin = nn.DataParallel(BandSplitFuse(dim=64, cutoff=_cutoff, mode=_mode)).to(device)
    Plugin_D = nn.DataParallel(BandSplitFuse(dim=64, cutoff=_cutoff, mode=_mode)).to(device) if _dual else None

    checkpoint = torch.load(ckpt_path, map_location=device)
    key_enc = 'CDDF_Encoder' if 'CDDF_Encoder' in checkpoint else 'DIDF_Encoder'
    key_dec = 'CDDF_Decoder' if 'CDDF_Decoder' in checkpoint else 'DIDF_Decoder'
    Encoder.load_state_dict(checkpoint[key_enc])
    Decoder.load_state_dict(checkpoint[key_dec])
    BaseFuseLayer.load_state_dict(checkpoint['BaseFuseLayer'])
    DetailFuseLayer.load_state_dict(checkpoint['DetailFuseLayer'])
    if plugin_ckpt is not None:
        pck = torch.load(plugin_ckpt, map_location=device)
        Plugin.load_state_dict(pck['FourierPlugin'])
        # v2 联合微调后融合层也更新了，一并加载（v1 里它们与原版相同，加载无副作用）
        BaseFuseLayer.load_state_dict(pck['BaseFuseLayer'])
        DetailFuseLayer.load_state_dict(pck['DetailFuseLayer'])
        if pck.get('dual_branch'):
            # v4 端到端模型：encoder/decoder 也用微调后的权重，加载 detail 支路插件
            Encoder.load_state_dict(pck['CDDF_Encoder'])
            Decoder.load_state_dict(pck['CDDF_Decoder'])
            Plugin_D.load_state_dict(pck['FourierPlugin_D'])
        test_out_folder = test_out_folder + "_" + tag.replace('.pth', '')
    for m in [Encoder, Decoder, BaseFuseLayer, DetailFuseLayer, Plugin] + ([Plugin_D] if _dual else []):
        m.eval()

    image_names = sorted(os.listdir(os.path.join(test_folder, "ir")))
    with torch.no_grad():
        for img_name in image_names:
            data_IR = image_read_cv2(os.path.join(test_folder, "ir", img_name), mode='GRAY')[np.newaxis, np.newaxis, ...] / 255.0
            data_VIS = image_read_cv2(os.path.join(test_folder, "vi", img_name), mode='GRAY')[np.newaxis, np.newaxis, ...] / 255.0
            data_VIS = torch.FloatTensor(data_VIS).to(device)
            data_IR = torch.FloatTensor(data_IR).to(device)

            feature_V_B, feature_V_D, _ = Encoder(data_VIS)
            feature_I_B, feature_I_D, _ = Encoder(data_IR)
            # === 插件插入点 ===
            if _dual:
                # v4 双支路：base + detail 都经频域融合（修正后顺序：ir 在前）
                feature_B_fused = Plugin(feature_I_B, feature_V_B)
                feature_F_D = DetailFuseLayer(Plugin_D(feature_I_D, feature_V_D))
            else:
                # v1~v3 单支路：与 forward(f_ir, f_vi) 及修正后的训练脚本一致
                feature_B_fused = Plugin(feature_I_B, feature_V_B)
                feature_F_D = DetailFuseLayer(feature_V_D + feature_I_D)
            feature_F_B = BaseFuseLayer(feature_B_fused)
            data_Fuse, _ = Decoder(data_VIS, feature_F_B, feature_F_D)
            data_min, data_max = torch.min(data_Fuse), torch.max(data_Fuse)
            data_Fuse = (data_Fuse - data_min) / (data_max - data_min).clamp_min(1e-8)
            fi = np.squeeze((data_Fuse * 255).cpu().numpy())
            img_save(fi, img_name.split(sep='.')[0], test_out_folder)

    eval_folder = test_out_folder
    ori_img_folder = test_folder

    metric_result = np.zeros((8))
    for img_name in image_names:
        ir = image_read_cv2(os.path.join(ori_img_folder, "ir", img_name), 'GRAY')
        vi = image_read_cv2(os.path.join(ori_img_folder, "vi", img_name), 'GRAY')
        fi = image_read_cv2(os.path.join(eval_folder, img_name.split('.')[0] + ".png"), 'GRAY')
        metric_result += np.array([Evaluator.EN(fi), Evaluator.SD(fi),
                                   Evaluator.SF(fi), Evaluator.MI(fi, ir, vi),
                                   Evaluator.SCD(fi, ir, vi), Evaluator.VIFF(fi, ir, vi),
                                   Evaluator.Qabf(fi, ir, vi), Evaluator.SSIM(fi, ir, vi)])

    metric_result /= len(image_names)
    print("\t\t EN\t SD\t SF\t MI\tSCD\tVIF\tQabf\tSSIM")
    print("CDDFuse+Plugin\t" + "\t".join(str(np.round(v, 2)) for v in metric_result))
    print("=" * 80)

print(f"\n插件参数量: {count_params(Plugin):,}")
