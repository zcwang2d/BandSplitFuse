# -*- coding: utf-8 -*-
"""Summarize paired fine-tuning logs without selecting seeds or checkpoints."""
from pathlib import Path
import argparse
import csv
import re

import numpy as np

METRICS = ["EN", "SD", "SF", "MI", "SCD", "VIF", "Qabf", "SSIMsum"]
SEEDS = [20261112, 20261113, 20261114]
DATASETS = ["MSRS", "TNO", "RoadScene"]
METHODS = {
    "Fine-tuned baseline": "test_finetune_baseline_seed{seed}.log",
    "BandSplitFuse": "test_finetune_full_seed{seed}.log",
    "Continuous variant": "test_finetune_full_continuous_reliability_seed{seed}.log",
}


def read_log(path):
    text = path.read_text(encoding="utf-8", errors="replace")
    rows = {}
    for dataset in DATASETS:
        match = re.search(
            rf"Fine-tune evaluation: {dataset}.*?FineTune\s+([0-9.eE+\-\s]+)",
            text,
            flags=re.DOTALL,
        )
        if not match:
            raise ValueError(f"missing {dataset} metrics in {path}")
        values = [float(value) for value in match.group(1).split()]
        if len(values) != len(METRICS):
            raise ValueError(f"unexpected metric count in {path}: {len(values)}")
        rows[dataset] = values
    return rows


def write_csv(path, fieldnames, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--log-dir", type=Path, default=Path("CDDFuse/controlled_experiments_20261112"))
    parser.add_argument("--output-dir", type=Path, default=Path("results"))
    args = parser.parse_args()
    per_run = []
    collected = {}
    for method, pattern in METHODS.items():
        for seed in SEEDS:
            values = read_log(args.log_dir / pattern.format(seed=seed))
            for dataset in DATASETS:
                collected[method, seed, dataset] = values[dataset]
                per_run.append({
                    "Method": method, "Seed": seed, "Dataset": dataset,
                    **dict(zip(METRICS, values[dataset])),
                })
    write_csv(args.output_dir / "three_seed_per_run.csv",
              ["Method", "Seed", "Dataset"] + METRICS, per_run)

    summary = []
    for dataset in DATASETS:
        for method in METHODS:
            array = np.array([collected[method, seed, dataset] for seed in SEEDS])
            mean = array.mean(axis=0)
            std = array.std(axis=0, ddof=1)
            summary.append({
                "Dataset": dataset, "Method": method,
                **{metric: f"{m:.2f} ± {s:.2f}" for metric, m, s in zip(METRICS, mean, std)},
            })
    write_csv(args.output_dir / "three_seed_mean_std.csv",
              ["Dataset", "Method"] + METRICS, summary)
    print(f"Wrote {len(per_run)} per-run rows and {len(summary)} summary rows to {args.output_dir}")


if __name__ == "__main__":
    main()
