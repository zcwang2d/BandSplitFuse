# -*- coding: utf-8 -*-
"""严格受控的 BandSplitFuse 即插即用消融训练。

所有配置均从同一个官方 CDDFuse 基线开始，冻结 Encoder、Decoder、
BaseFuseLayer 和 DetailFuseLayer，仅训练插件。使用原始 Fusionloss，
不从 v2/v3 热启动，也不重加权损失。

用法：python train_plugin_ablation.py [epochs] [lr] [max_batches] [mode] [cutoff]
  mode: full / amp_only / phase_only
"""
import datetime
import os
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'FourierFuse'))
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
os.environ['PYTORCH_ALLOC_CONF'] = 'expandable_segments:True'

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from fourier_plugin import BandSplitFuse, count_params
from net import Restormer_Encoder, Restormer_Decoder, BaseFeatureExtraction, DetailFeatureExtraction
from utils.dataset import H5Dataset
from utils.loss import Fusionloss

os.environ['CUDA_VISIBLE_DEVICES'] = '0'

num_epochs = int(sys.argv[1]) if len(sys.argv) > 1 else 20
lr = float(sys.argv[2]) if len(sys.argv) > 2 else 1e-4
max_batches = int(sys.argv[3]) if len(sys.argv) > 3 else 0
ab_mode = sys.argv[4] if len(sys.argv) > 4 else 'full'
cutoff = float(sys.argv[5]) if len(sys.argv) > 5 else 0.125
if ab_mode not in ('full', 'amp_only', 'phase_only'):
    raise ValueError(f'未知消融模式: {ab_mode}')

SEED = 20261108
np.random.seed(SEED)
torch.manual_seed(SEED)
torch.cuda.manual_seed_all(SEED)

batch_size = 2
clip_grad_norm_value = 0.01
optim_step = 8
optim_gamma = 0.5
device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f'[严格PnP消融] device={device}, mode={ab_mode}, cutoff={cutoff}, '
      f'epochs={num_epochs}, lr={lr}, seed={SEED}', flush=True)

Encoder = nn.DataParallel(Restormer_Encoder()).to(device)
Decoder = nn.DataParallel(Restormer_Decoder()).to(device)
BaseFuseLayer = nn.DataParallel(BaseFeatureExtraction(dim=64, num_heads=8)).to(device)
DetailFuseLayer = nn.DataParallel(DetailFeatureExtraction(num_layers=1)).to(device)
Plugin = nn.DataParallel(BandSplitFuse(dim=64, cutoff=cutoff, mode=ab_mode)).to(device)

ckpt = torch.load(r'models/CDDFuse_IVF.pth', map_location=device)
key_enc = 'CDDF_Encoder' if 'CDDF_Encoder' in ckpt else 'DIDF_Encoder'
key_dec = 'CDDF_Decoder' if 'CDDF_Decoder' in ckpt else 'DIDF_Decoder'
Encoder.load_state_dict(ckpt[key_enc])
Decoder.load_state_dict(ckpt[key_dec])
BaseFuseLayer.load_state_dict(ckpt['BaseFuseLayer'])
DetailFuseLayer.load_state_dict(ckpt['DetailFuseLayer'])

for module in (Encoder, Decoder, BaseFuseLayer, DetailFuseLayer):
    module.eval()
    for parameter in module.parameters():
        parameter.requires_grad_(False)
Plugin.train()
for parameter in Plugin.parameters():
    parameter.requires_grad_(True)
print(f'仅插件可训练: {count_params(Plugin):,} 参数；两个融合层均冻结', flush=True)

optimizer = torch.optim.Adam(Plugin.parameters(), lr=lr, weight_decay=0)
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=optim_step, gamma=optim_gamma)
criteria_fusion = Fusionloss().to(device)
trainloader = DataLoader(
    H5Dataset(r'data/MSRS_train_imgsize_128_stride_200.h5'),
    batch_size=batch_size, shuffle=True, num_workers=0,
    generator=torch.Generator().manual_seed(SEED),
)

timestamp = datetime.datetime.now().strftime('%m-%d-%H-%M')
torch.backends.cudnn.benchmark = True
prev_time = time.time()

for epoch in range(num_epochs):
    for i, (data_VIS, data_IR) in enumerate(trainloader):
        if max_batches and i >= max_batches:
            break
        data_VIS, data_IR = data_VIS.to(device), data_IR.to(device)
        Plugin.train()
        optimizer.zero_grad()

        with torch.no_grad():
            feature_V_B, feature_V_D, _ = Encoder(data_VIS)
            feature_I_B, feature_I_D, _ = Encoder(data_IR)
            feature_F_D = DetailFuseLayer(feature_V_D + feature_I_D)

        # BandSplitFuse.forward(f_ir, f_vi)：红外必须在前。
        feature_B_fused = Plugin(feature_I_B, feature_V_B)
        feature_F_B = BaseFuseLayer(feature_B_fused)
        data_Fuse, _ = Decoder(data_VIS, feature_F_B, feature_F_D)

        loss, loss_in, loss_grad = criteria_fusion(data_VIS, data_IR, data_Fuse)
        loss.backward()
        nn.utils.clip_grad_norm_(Plugin.parameters(), max_norm=clip_grad_norm_value, norm_type=2)
        optimizer.step()

        batches_done = epoch * len(trainloader) + i
        batches_left = num_epochs * len(trainloader) - batches_done
        time_left = datetime.timedelta(seconds=batches_left * (time.time() - prev_time))
        prev_time = time.time()
        sys.stdout.write(
            f'\r[Epoch {epoch}/{num_epochs}] [Batch {i}/{len(trainloader)}] '
            f'[loss {loss.item():.6f}; in {loss_in.item():.4f}; grad {loss_grad.item():.4f}] '
            f'ETA: {time_left}')
        sys.stdout.flush()

    scheduler.step()
    if optimizer.param_groups[0]['lr'] <= 1e-6:
        optimizer.param_groups[0]['lr'] = 1e-6

    peak_gb = torch.cuda.max_memory_allocated() / 1e9 if device == 'cuda' else 0.0
    save = {
        'CDDF_Encoder': Encoder.state_dict(),
        'CDDF_Decoder': Decoder.state_dict(),
        'BaseFuseLayer': BaseFuseLayer.state_dict(),
        'DetailFuseLayer': DetailFuseLayer.state_dict(),
        'FourierPlugin': Plugin.state_dict(),
        'ab_mode': ab_mode,
        'cutoff': cutoff,
        'protocol': 'frozen_entire_backbone_plugin_only_standard_fusion_loss',
        'input_order': 'ir_vi',
        'seed': SEED,
        'optimizer': optimizer.state_dict(),
        'scheduler': scheduler.state_dict(),
    }
    output = f'models/CDDFuse_pnpAb_{ab_mode}_c{cutoff}_{timestamp}_ep{epoch}.pth'
    torch.save(save, output)
    print(f'\n[epoch {epoch}] saved={output}, lr={optimizer.param_groups[0]["lr"]:.2e}, '
          f'显存峰值={peak_gb:.2f} GB', flush=True)
    if peak_gb > 7.5:
        print('!! 显存峰值超过 7.5GB 安全线，请减小 batch_size !!', flush=True)

print(f'\n严格PnP消融完成: mode={ab_mode}, cutoff={cutoff}, prefix=CDDFuse_pnpAb_', flush=True)
