# -*- coding: utf-8 -*-
"""Wait for the controlled queue, then run fair fusion-layer fine-tuning automatically."""
from pathlib import Path
import datetime
import glob
import json
import os
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
OUT = HERE / "controlled_experiments_20261112"
FIRST_STATUS = OUT / "queue_status.json"
STATUS = OUT / "finetune_queue_status.json"
CONFIGS = [("baseline", 20261112), ("full", 20261112)]


def now():
    return datetime.datetime.now().isoformat(timespec="seconds")


def write_status(state):
    STATUS.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


def final_checkpoint(mode, seed):
    files = glob.glob(str(HERE / "models" / f"CDDFuse_finetune_{mode}_seed{seed}_*_ep19.pth"))
    return max(files, key=os.path.getmtime) if files else None


state = {"status": "waiting_for_controlled_queue", "created_at": now(), "configs": []}
write_status(state)
while True:
    try:
        first = json.loads(FIRST_STATUS.read_text(encoding="utf-8"))
        first_status = first.get("status")
    except Exception:
        first_status = "missing"
    if first_status == "completed":
        break
    if first_status in {"failed", "cancelled"}:
        state["status"] = "not_started_upstream_" + first_status
        write_status(state)
        sys.exit(3)
    time.sleep(60)

state["status"] = "running"
state["started_at"] = now()
write_status(state)

for mode, seed in CONFIGS:
    tag = f"finetune_{mode}_seed{seed}"
    entry = {"tag": tag, "mode": mode, "seed": seed, "status": "running", "started_at": now()}
    state["current"] = tag
    state["configs"] = [item for item in state["configs"] if item["tag"] != tag] + [entry]
    write_status(state)
    checkpoint = final_checkpoint(mode, seed)
    if checkpoint is None:
        train_log = OUT / f"train_{tag}.log"
        with train_log.open("a", encoding="utf-8") as stream:
            stream.write(f"\n\n=== run {now()} ===\n")
            stream.flush()
            result = subprocess.run(
                [sys.executable, "-u", "train_fusion_finetune.py", "--mode", mode, "--seed", str(seed), "--epochs", "20"],
                cwd=HERE, stdout=stream, stderr=subprocess.STDOUT,
            )
        entry["train_returncode"] = result.returncode
        if result.returncode != 0:
            entry["status"] = "failed_training"
            state["status"] = "failed"
            write_status(state)
            sys.exit(result.returncode)
        checkpoint = final_checkpoint(mode, seed)
    if checkpoint is None:
        entry["status"] = "missing_final_checkpoint"
        state["status"] = "failed"
        write_status(state)
        sys.exit(2)

    entry["checkpoint"] = checkpoint
    test_log = OUT / f"test_{tag}.log"
    with test_log.open("w", encoding="utf-8") as stream:
        result = subprocess.run(
            [sys.executable, "-u", "test_fusion_finetune.py", checkpoint, "MSRS,TNO,RoadScene"],
            cwd=HERE, stdout=stream, stderr=subprocess.STDOUT,
        )
    entry["test_returncode"] = result.returncode
    if result.returncode != 0:
        entry["status"] = "failed_testing"
        state["status"] = "failed"
        write_status(state)
        sys.exit(result.returncode)
    entry["status"] = "completed"
    entry["completed_at"] = now()
    state["configs"] = [item for item in state["configs"] if item["tag"] != tag] + [entry]
    write_status(state)

state["status"] = "completed"
state["current"] = None
state["completed_at"] = now()
write_status(state)
print("ALL_FINETUNE_EXPERIMENTS_DONE", flush=True)
