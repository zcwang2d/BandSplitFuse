# -*- coding: utf-8 -*-
"""CDDFuse + FourierFusion 插件：从头完整训练（MSRS，120 epoch）。

与官方 CDDFuse 训练完全一致的两阶段流程，唯一区别：
  Phase II 的 base / detail 特征先经 BandSplitFuse 频域融合（双支路插件）。
损失函数保持原版（fusionloss + 2*decomp），保证对比实验的公平性：
  baseline = 官方 CDDFuse_IVF.pth，ours = 同配方 + 插件。

支持断点恢复：自动扫描 models/CDDFuseFULL_*_ep{N}.pth，从最新处继续。

用法：python train_full_plugin.py [num_epochs] [phase_I_epochs]
"""
import sys
import os
import re
import glob

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'FourierFuse'))
from fourier_plugin import BandSplitFuse, count_params

from net import Restormer_Encoder, Restormer_Decoder, BaseFeatureExtraction, DetailFeatureExtraction
from utils.dataset import H5Dataset
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
os.environ['PYTORCH_ALLOC_CONF'] = 'expandable_segments:True'
import time
import datetime
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from utils.loss import Fusionloss, cc
import kornia

os.environ['CUDA_VISIBLE_DEVICES'] = '0'

num_epochs = int(sys.argv[1]) if len(sys.argv) > 1 else 120
epoch_gap = int(sys.argv[2]) if len(sys.argv) > 2 else 40   # Phase I 重建 / Phase II 融合

lr = 1e-4
batch_size = 2          # 8GB 显存安全上限
coeff_mse_loss_VF = 1.
coeff_mse_loss_IF = 1.
coeff_decomp = 2.
coeff_tv = 5.
clip_grad_norm_value = 0.01
optim_step = 20
optim_gamma = 0.5

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"[完整重训] device: {device}, epochs: {num_epochs}, phase-I/II gap: {epoch_gap}")

criteria_fusion = Fusionloss().to(device)
Encoder = nn.DataParallel(Restormer_Encoder()).to(device)
Decoder = nn.DataParallel(Restormer_Decoder()).to(device)
BaseFuseLayer = nn.DataParallel(BaseFeatureExtraction(dim=64, num_heads=8)).to(device)
DetailFuseLayer = nn.DataParallel(DetailFeatureExtraction(num_layers=1)).to(device)
Plugin_B = nn.DataParallel(BandSplitFuse(dim=64)).to(device)
Plugin_D = nn.DataParallel(BandSplitFuse(dim=64)).to(device)
modules = [Encoder, Decoder, BaseFuseLayer, DetailFuseLayer, Plugin_B, Plugin_D]

optimizers = [torch.optim.Adam(m.parameters(), lr=lr, weight_decay=0) for m in modules]
schedulers = [torch.optim.lr_scheduler.StepLR(o, step_size=optim_step, gamma=optim_gamma)
              for o in optimizers]

MSELoss = nn.MSELoss()
L1Loss = nn.L1Loss()
Loss_ssim = kornia.losses.SSIMLoss(11, reduction='mean')

trainloader = DataLoader(H5Dataset(r"data/MSRS_train_imgsize_128_stride_200.h5"),
                         batch_size=batch_size, shuffle=True, num_workers=0)

# ---------------- 断点恢复 ----------------
start_epoch = 0
existing = glob.glob(r"models/CDDFuseFULL_*_ep*.pth")
if existing:
    def _ep(p):
        m = re.search(r'_ep(\d+)\.pth$', p)
        return int(m.group(1)) if m else -1
    latest = max(existing, key=lambda p: (_ep(p), os.path.getmtime(p)))
    pck = torch.load(latest, map_location=device)
    Encoder.load_state_dict(pck['CDDF_Encoder'])
    Decoder.load_state_dict(pck['CDDF_Decoder'])
    BaseFuseLayer.load_state_dict(pck['BaseFuseLayer'])
    DetailFuseLayer.load_state_dict(pck['DetailFuseLayer'])
    Plugin_B.load_state_dict(pck['FourierPlugin'])
    Plugin_D.load_state_dict(pck['FourierPlugin_D'])
    if 'optimizers' in pck:
        for o, sd in zip(optimizers, pck['optimizers']):
            o.load_state_dict(sd)
    start_epoch = _ep(latest) + 1
    for s in schedulers:
        for _ in range(start_epoch):
            s.step()
    print(f"从 {os.path.basename(latest)} 恢复，从 epoch {start_epoch} 继续")

torch.backends.cudnn.benchmark = True
prev_time = time.time()
timestamp = datetime.datetime.now().strftime("%m-%d-%H-%M")

for epoch in range(start_epoch, num_epochs):
    for i, (data_VIS, data_IR) in enumerate(trainloader):
        data_VIS, data_IR = data_VIS.to(device), data_IR.to(device)
        for m in modules:
            m.train()
            m.zero_grad()
        for o in optimizers:
            o.zero_grad()

        if epoch < epoch_gap:  # Phase I：重建（插件不参与，与官方流程一致）
            feature_V_B, feature_V_D, _ = Encoder(data_VIS)
            feature_I_B, feature_I_D, _ = Encoder(data_IR)
            data_VIS_hat, _ = Decoder(data_VIS, feature_V_B, feature_V_D)
            data_IR_hat, _ = Decoder(data_IR, feature_I_B, feature_I_D)
            cc_loss_B = cc(feature_V_B, feature_I_B)
            cc_loss_D = cc(feature_V_D, feature_I_D)
            mse_loss_V = 5 * Loss_ssim(data_VIS, data_VIS_hat) + MSELoss(data_VIS, data_VIS_hat)
            mse_loss_I = 5 * Loss_ssim(data_IR, data_IR_hat) + MSELoss(data_IR, data_IR_hat)
            Gradient_loss = L1Loss(kornia.filters.SpatialGradient()(data_VIS),
                                   kornia.filters.SpatialGradient()(data_VIS_hat))
            loss_decomp = (cc_loss_D) ** 2 / (1.01 + cc_loss_B)
            loss = coeff_mse_loss_VF * mse_loss_V + coeff_mse_loss_IF * \
                   mse_loss_I + coeff_decomp * loss_decomp + coeff_tv * Gradient_loss
            loss.backward()
            nn.utils.clip_grad_norm_(Encoder.parameters(), max_norm=clip_grad_norm_value, norm_type=2)
            nn.utils.clip_grad_norm_(Decoder.parameters(), max_norm=clip_grad_norm_value, norm_type=2)
            optimizers[0].step(); optimizers[1].step()
        else:  # Phase II：融合（插件双支路插入，其余与官方一致）
            feature_V_B, feature_V_D, feature_V = Encoder(data_VIS)
            feature_I_B, feature_I_D, feature_I = Encoder(data_IR)
            # === 唯一的改动：base/detail 特征先经频域插件融合（ir 在前）===
            feature_F_B = BaseFuseLayer(Plugin_B(feature_I_B, feature_V_B))
            feature_F_D = DetailFuseLayer(Plugin_D(feature_I_D, feature_V_D))
            data_Fuse, feature_F = Decoder(data_VIS, feature_F_B, feature_F_D)
            cc_loss_B = cc(feature_V_B, feature_I_B)
            cc_loss_D = cc(feature_V_D, feature_I_D)
            loss_decomp = (cc_loss_D) ** 2 / (1.01 + cc_loss_B)
            fusionloss, _, _ = criteria_fusion(data_VIS, data_IR, data_Fuse)
            loss = fusionloss + coeff_decomp * loss_decomp
            loss.backward()
            for m in modules:
                nn.utils.clip_grad_norm_(m.parameters(), max_norm=clip_grad_norm_value, norm_type=2)
            for o in optimizers:
                o.step()

        batches_done = epoch * len(trainloader) + i
        batches_left = num_epochs * len(trainloader) - batches_done
        time_left = datetime.timedelta(seconds=batches_left * (time.time() - prev_time))
        prev_time = time.time()
        phase = "I" if epoch < epoch_gap else "II"
        sys.stdout.write(
            "\r[Epoch %d/%d][Phase %s] [Batch %d/%d] [loss: %f] ETA: %.10s"
            % (epoch, num_epochs, phase, i, len(trainloader), loss.item(), time_left))

    for s in schedulers:
        s.step()
    for o in optimizers:
        if o.param_groups[0]['lr'] <= 1e-6:
            o.param_groups[0]['lr'] = 1e-6

    peak_gb = torch.cuda.max_memory_allocated() / 1e9
    ckpt = {
        'CDDF_Encoder': Encoder.state_dict(),
        'CDDF_Decoder': Decoder.state_dict(),
        'BaseFuseLayer': BaseFuseLayer.state_dict(),
        'DetailFuseLayer': DetailFuseLayer.state_dict(),
        'FourierPlugin': Plugin_B.state_dict(),
        'FourierPlugin_D': Plugin_D.state_dict(),
        'optimizers': [o.state_dict() for o in optimizers],
        'ab_mode': 'full', 'cutoff': 0.125, 'dual_branch': True,
    }
    torch.save(ckpt, os.path.join(f"models/CDDFuseFULL_{timestamp}_ep{epoch}.pth"))
    print(f"\n[epoch {epoch}] saved, 显存峰值 {peak_gb:.2f} GB")
    if peak_gb > 7.5:
        print("!! 显存峰值超过 7.5GB 安全线 !!")

print(f"\n训练完成，模型前缀: models/CDDFuseFULL_{timestamp}_ep*.pth")
