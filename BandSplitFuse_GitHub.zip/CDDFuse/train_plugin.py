# -*- coding: utf-8 -*-
"""FourierFusion 插件训练脚本：冻结 CDDFuse 主干，只训练插件。

策略：
  - 加载预训练 CDDFuse_IVF.pth，冻结 Encoder / Decoder / BaseFuseLayer / DetailFuseLayer
  - 在 base 特征相加处插入 BandSplitFuse（零初始化，起步性能 = 原版）
  - 用 Phase II 融合损失只训练插件参数（约 29K），性能提升可干净归因于插件
  - 编码器/细节支路在 no_grad 下前向，省显存；梯度仍可经融合层回传到插件

用法：python train_plugin.py [num_epochs] [lr] [max_batches(冒烟用)]
"""
import os
import sys
import time
import datetime

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'FourierFuse'))
os.environ['KMP_DUPLICATE_LIB_OK'] = 'True'
# 8GB 显存安全护栏：可扩展段减少碎片
os.environ['PYTORCH_ALLOC_CONF'] = 'expandable_segments:True'

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from fourier_plugin import BandSplitFuse, count_params
from net import Restormer_Encoder, Restormer_Decoder, BaseFeatureExtraction, DetailFeatureExtraction
from utils.dataset import H5Dataset
from utils.loss import Fusionloss

os.environ['CUDA_VISIBLE_DEVICES'] = '0'

num_epochs = int(sys.argv[1]) if len(sys.argv) > 1 else 20
lr = float(sys.argv[2]) if len(sys.argv) > 2 else 1e-4
max_batches = int(sys.argv[3]) if len(sys.argv) > 3 else 0   # >0 时每个 epoch 只跑这么多批（冒烟）
resume_ckpt = sys.argv[4] if len(sys.argv) > 4 else None     # 断点恢复：插件权重路径

batch_size = 2          # 8GB 显存安全上限：bs=2 峰值约 5.5GB，严禁 bs>=4
clip_grad_norm_value = 0.01
optim_step = 8          # 插件参数少，学习率衰减快一点
optim_gamma = 0.5

device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"device: {device}, epochs: {num_epochs}, lr: {lr}, bs: {batch_size}")

# ---------------- 模型：加载预训练主干并冻结 ----------------
Encoder = nn.DataParallel(Restormer_Encoder()).to(device)
Decoder = nn.DataParallel(Restormer_Decoder()).to(device)
BaseFuseLayer = nn.DataParallel(BaseFeatureExtraction(dim=64, num_heads=8)).to(device)
DetailFuseLayer = nn.DataParallel(DetailFeatureExtraction(num_layers=1)).to(device)
Plugin = nn.DataParallel(BandSplitFuse(dim=64)).to(device)

ckpt = torch.load(r"models/CDDFuse_IVF.pth", map_location=device)
key_enc = 'CDDF_Encoder' if 'CDDF_Encoder' in ckpt else 'DIDF_Encoder'
key_dec = 'CDDF_Decoder' if 'CDDF_Decoder' in ckpt else 'DIDF_Decoder'
Encoder.load_state_dict(ckpt[key_enc])
Decoder.load_state_dict(ckpt[key_dec])
BaseFuseLayer.load_state_dict(ckpt['BaseFuseLayer'])
DetailFuseLayer.load_state_dict(ckpt['DetailFuseLayer'])
print(f"主干权重已加载（encoder key: {key_enc}）")

for m in (Encoder, Decoder, BaseFuseLayer, DetailFuseLayer):
    m.eval()                                    # 冻结：eval 模式
    for p in m.parameters():
        p.requires_grad_(False)
Plugin.train()
print(f"插件可训练参数: {count_params(Plugin):,}（其余全部冻结）")

optimizer = torch.optim.Adam(Plugin.parameters(), lr=lr, weight_decay=0)
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=optim_step, gamma=optim_gamma)
criteria_fusion = Fusionloss().to(device)

start_epoch = 0
if resume_ckpt:
    import re
    pck = torch.load(resume_ckpt, map_location=device)
    Plugin.load_state_dict(pck['FourierPlugin'])
    m = re.search(r'_ep(\d+)', os.path.basename(resume_ckpt))
    start_epoch = int(m.group(1)) + 1 if m else 0
    for _ in range(start_epoch):
        scheduler.step()
    print(f"从 {os.path.basename(resume_ckpt)} 恢复插件权重，从 epoch {start_epoch} 继续，"
          f"lr={optimizer.param_groups[0]['lr']:.2e}")

trainloader = DataLoader(H5Dataset(r"data/MSRS_train_imgsize_128_stride_200.h5"),
                         batch_size=batch_size, shuffle=True, num_workers=0)
timestamp = datetime.datetime.now().strftime("%m-%d-%H-%M")

torch.backends.cudnn.benchmark = True
prev_time = time.time()

for epoch in range(start_epoch, num_epochs):
    for i, (data_VIS, data_IR) in enumerate(trainloader):
        if max_batches and i >= max_batches:
            break
        data_VIS, data_IR = data_VIS.to(device), data_IR.to(device)
        Plugin.train()
        optimizer.zero_grad()

        with torch.no_grad():   # 冻结支路：不回传梯度，省显存
            feature_V_B, feature_V_D, _ = Encoder(data_VIS)
            feature_I_B, feature_I_D, _ = Encoder(data_IR)
            feature_F_D = DetailFuseLayer(feature_V_D + feature_I_D)

        # === 插件插入点：参数顺序必须与 forward(f_ir, f_vi) 一致 ===
        feature_B_fused = Plugin(feature_I_B, feature_V_B)
        feature_F_B = BaseFuseLayer(feature_B_fused)     # 权重冻结，但梯度可穿回插件
        data_Fuse, _ = Decoder(data_VIS, feature_F_B, feature_F_D)

        loss, _, _ = criteria_fusion(data_VIS, data_IR, data_Fuse)
        loss.backward()
        nn.utils.clip_grad_norm_(Plugin.parameters(), max_norm=clip_grad_norm_value, norm_type=2)
        optimizer.step()

        batches_done = epoch * len(trainloader) + i
        batches_left = num_epochs * len(trainloader) - batches_done
        time_left = datetime.timedelta(seconds=batches_left * (time.time() - prev_time))
        prev_time = time.time()
        sys.stdout.write(
            "\r[Epoch %d/%d] [Batch %d/%d] [fusion loss: %f] ETA: %.10s"
            % (epoch, num_epochs, i, len(trainloader), loss.item(), time_left))

    scheduler.step()
    if optimizer.param_groups[0]['lr'] <= 1e-6:
        optimizer.param_groups[0]['lr'] = 1e-6

    # 每个 epoch 都存盘（含冻结主干，单文件即可直接测试），崩溃不丢进度
    peak_gb = torch.cuda.max_memory_allocated() / 1e9
    save = {
        'CDDF_Encoder': Encoder.state_dict(),
        'CDDF_Decoder': Decoder.state_dict(),
        'BaseFuseLayer': BaseFuseLayer.state_dict(),
        'DetailFuseLayer': DetailFuseLayer.state_dict(),
        'FourierPlugin': Plugin.state_dict(),
    }
    torch.save(save, os.path.join(f"models/CDDFuse_plugin_{timestamp}_ep{epoch}.pth"))
    print(f"\n[epoch {epoch}] saved, lr={optimizer.param_groups[0]['lr']:.2e}, 显存峰值 {peak_gb:.2f} GB")
    if peak_gb > 7.5:
        print("!! 显存峰值超过 7.5GB 安全线，请减小 batch_size !!")

print(f"\n训练完成，模型前缀: models/CDDFuse_plugin_{timestamp}_ep*.pth")
