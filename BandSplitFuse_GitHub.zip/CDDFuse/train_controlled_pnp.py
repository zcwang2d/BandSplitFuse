# -*- coding: utf-8 -*-
"""Controlled dual-branch BandSplitFuse training on a frozen official CDDFuse host.

Only the two plug-ins are trainable. The host, data, loss, epoch count, and
optimizer recipe are fixed across modes and seeds. The final epoch is used for
evaluation; no test-set checkpoint selection is performed.

Example:
    python -u train_controlled_pnp.py --mode full --seed 20261112 --epochs 20
"""
import argparse
import datetime
import glob
import os
from pathlib import Path
import re
import sys
import time

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "FourierFuse"))
os.environ["KMP_DUPLICATE_LIB_OK"] = "True"
os.environ["PYTORCH_ALLOC_CONF"] = "expandable_segments:True"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

from fourier_plugin import BandSplitFuse, count_params
from net import Restormer_Encoder, Restormer_Decoder, BaseFeatureExtraction, DetailFeatureExtraction
from utils.dataset import H5Dataset
from utils.loss import Fusionloss


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["full", "amp_only", "phase_only"], required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--cutoff", type=float, default=0.125)
    parser.add_argument("--max-batches", type=int, default=0, help="Smoke-test limit; 0 means all batches")
    return parser.parse_args()


def epoch_of(path):
    match = re.search(r"_ep(\d+)\.pth$", path)
    return int(match.group(1)) if match else -1


def main():
    args = parse_args()
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    np.random.seed(args.seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True

    batch_size = 2
    lr = 1e-4
    clip_grad_norm_value = 0.01
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"[controlled-pnp] mode={args.mode}, seed={args.seed}, cutoff={args.cutoff}, "
          f"epochs={args.epochs}, device={device}, batch_size={batch_size}", flush=True)

    # Instantiate in the same order for every configuration.
    Encoder = nn.DataParallel(Restormer_Encoder()).to(device)
    Decoder = nn.DataParallel(Restormer_Decoder()).to(device)
    BaseFuseLayer = nn.DataParallel(BaseFeatureExtraction(dim=64, num_heads=8)).to(device)
    DetailFuseLayer = nn.DataParallel(DetailFeatureExtraction(num_layers=1)).to(device)
    Plugin_B = nn.DataParallel(BandSplitFuse(dim=64, cutoff=args.cutoff, mode=args.mode)).to(device)
    Plugin_D = nn.DataParallel(BandSplitFuse(dim=64, cutoff=args.cutoff, mode=args.mode)).to(device)

    host = torch.load(HERE / "models" / "CDDFuse_IVF.pth", map_location=device)
    key_enc = "CDDF_Encoder" if "CDDF_Encoder" in host else "DIDF_Encoder"
    key_dec = "CDDF_Decoder" if "CDDF_Decoder" in host else "DIDF_Decoder"
    Encoder.load_state_dict(host[key_enc])
    Decoder.load_state_dict(host[key_dec])
    BaseFuseLayer.load_state_dict(host["BaseFuseLayer"])
    DetailFuseLayer.load_state_dict(host["DetailFuseLayer"])

    for module in (Encoder, Decoder, BaseFuseLayer, DetailFuseLayer):
        module.eval()
        for parameter in module.parameters():
            parameter.requires_grad_(False)
    for module in (Plugin_B, Plugin_D):
        module.train()
        for parameter in module.parameters():
            parameter.requires_grad_(True)
    trainable = sum(p.numel() for module in (Plugin_B, Plugin_D) for p in module.parameters() if p.requires_grad)
    print(f"trainable plug-in parameters={trainable:,}; per insertion={count_params(Plugin_B):,}", flush=True)

    parameters = list(Plugin_B.parameters()) + list(Plugin_D.parameters())
    optimizer = torch.optim.Adam(parameters, lr=lr, weight_decay=0)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=8, gamma=0.5)
    criteria_fusion = Fusionloss().to(device)
    trainloader = DataLoader(
        H5Dataset(str(HERE / "data" / "MSRS_train_imgsize_128_stride_200.h5")),
        batch_size=batch_size,
        shuffle=True,
        num_workers=0,
        generator=torch.Generator().manual_seed(args.seed),
    )

    pattern = str(HERE / "models" / f"CDDFuse_ctrl_{args.mode}_seed{args.seed}_*_ep*.pth")
    existing = glob.glob(pattern)
    start_epoch = 0
    timestamp = datetime.datetime.now().strftime("%m-%d-%H-%M")
    if existing:
        latest = max(existing, key=lambda path: (epoch_of(path), os.path.getmtime(path)))
        checkpoint = torch.load(latest, map_location=device)
        Plugin_B.load_state_dict(checkpoint["FourierPlugin"])
        Plugin_D.load_state_dict(checkpoint["FourierPlugin_D"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        scheduler.load_state_dict(checkpoint["scheduler"])
        start_epoch = epoch_of(latest) + 1
        timestamp = checkpoint.get("timestamp", timestamp)
        print(f"resume={os.path.basename(latest)}; start_epoch={start_epoch}", flush=True)

    previous = time.time()
    for epoch in range(start_epoch, args.epochs):
        for index, (data_VIS, data_IR) in enumerate(trainloader):
            if args.max_batches and index >= args.max_batches:
                break
            data_VIS, data_IR = data_VIS.to(device), data_IR.to(device)
            Plugin_B.train()
            Plugin_D.train()
            optimizer.zero_grad()
            with torch.no_grad():
                feature_V_B, feature_V_D, _ = Encoder(data_VIS)
                feature_I_B, feature_I_D, _ = Encoder(data_IR)
            feature_F_B = BaseFuseLayer(Plugin_B(feature_I_B, feature_V_B))
            feature_F_D = DetailFuseLayer(Plugin_D(feature_I_D, feature_V_D))
            data_Fuse, _ = Decoder(data_VIS, feature_F_B, feature_F_D)
            loss, loss_in, loss_grad = criteria_fusion(data_VIS, data_IR, data_Fuse)
            loss.backward()
            nn.utils.clip_grad_norm_(parameters, max_norm=clip_grad_norm_value, norm_type=2)
            optimizer.step()

            elapsed = time.time() - previous
            previous = time.time()
            batches_done = epoch * len(trainloader) + index
            batches_left = args.epochs * len(trainloader) - batches_done
            eta = datetime.timedelta(seconds=batches_left * elapsed)
            sys.stdout.write(
                f"\r[Epoch {epoch}/{args.epochs}] [Batch {index}/{len(trainloader)}] "
                f"[loss {loss.item():.6f}; in {loss_in.item():.4f}; grad {loss_grad.item():.4f}] ETA: {eta}"
            )
            sys.stdout.flush()

        scheduler.step()
        if optimizer.param_groups[0]["lr"] <= 1e-6:
            optimizer.param_groups[0]["lr"] = 1e-6
        peak_gb = torch.cuda.max_memory_allocated() / 1e9 if device == "cuda" else 0.0
        output = HERE / "models" / f"CDDFuse_ctrl_{args.mode}_seed{args.seed}_{timestamp}_ep{epoch}.pth"
        torch.save({
            "CDDF_Encoder": Encoder.state_dict(),
            "CDDF_Decoder": Decoder.state_dict(),
            "BaseFuseLayer": BaseFuseLayer.state_dict(),
            "DetailFuseLayer": DetailFuseLayer.state_dict(),
            "FourierPlugin": Plugin_B.state_dict(),
            "FourierPlugin_D": Plugin_D.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(),
            "ab_mode": args.mode,
            "cutoff": args.cutoff,
            "dual_branch": True,
            "seed": args.seed,
            "epoch": epoch,
            "timestamp": timestamp,
            "protocol": "frozen_official_cddfuse_dual_branch_plugin_only_standard_fusion_loss",
            "input_order": "ir_vi",
            "batch_size": batch_size,
            "max_batches": args.max_batches,
        }, output)
        print(f"\n[epoch {epoch}] saved={output.name}; lr={optimizer.param_groups[0]['lr']:.2e}; "
              f"peak_gpu={peak_gb:.2f} GB", flush=True)
        if args.max_batches:
            break
    print("CONTROLLED_TRAINING_DONE", flush=True)


if __name__ == "__main__":
    main()
