# -*- coding: utf-8 -*-
"""Fair fusion-layer fine-tuning comparison with or without dual-band plug-ins."""
import argparse
import datetime
import glob
import os
from pathlib import Path
import re
import sys
import time

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "FourierFuse"))
os.environ["KMP_DUPLICATE_LIB_OK"] = "True"
os.environ["PYTORCH_ALLOC_CONF"] = "expandable_segments:True"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

from fourier_plugin import BandSplitFuse
from fourier_plugin_residual import ResidualBandSplitFuse, CircularBandSplitFuse, ResidualCircularBandSplitFuse
from fourier_plugin_continuous import ContinuousSpectralReliabilityFuse
from net import Restormer_Encoder, Restormer_Decoder, BaseFeatureExtraction, DetailFeatureExtraction
from utils.dataset import H5Dataset
from utils.loss import Fusionloss

PLUGIN_CLASSES = {
    "original": BandSplitFuse,
    "residual_only": ResidualBandSplitFuse,
    "circular_only": CircularBandSplitFuse,
    "residual_circular": ResidualCircularBandSplitFuse,
    "continuous_reliability": ContinuousSpectralReliabilityFuse,
}


def epoch_of(path):
    match = re.search(r"_ep(\d+)\.pth$", path)
    return int(match.group(1)) if match else -1


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["baseline", "full"], required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--epochs", type=int, default=20)
    parser.add_argument("--max-batches", type=int, default=0)
    parser.add_argument("--plugin-variant", choices=list(PLUGIN_CLASSES), default="original")
    args = parser.parse_args()
    use_plugin = args.mode == "full"
    plugin_class = PLUGIN_CLASSES[args.plugin_variant]
    run_mode = args.mode if args.plugin_variant == "original" else f"{args.mode}_{args.plugin_variant}"

    torch.manual_seed(args.seed)
    torch.cuda.manual_seed_all(args.seed)
    np.random.seed(args.seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"[fusion-finetune] mode={args.mode}; variant={args.plugin_variant}; seed={args.seed}; epochs={args.epochs}; device={device}", flush=True)

    Encoder = nn.DataParallel(Restormer_Encoder()).to(device)
    Decoder = nn.DataParallel(Restormer_Decoder()).to(device)
    BaseFuseLayer = nn.DataParallel(BaseFeatureExtraction(dim=64, num_heads=8)).to(device)
    DetailFuseLayer = nn.DataParallel(DetailFeatureExtraction(num_layers=1)).to(device)
    Plugin_B = nn.DataParallel(plugin_class(dim=64)).to(device) if use_plugin else None
    Plugin_D = nn.DataParallel(plugin_class(dim=64)).to(device) if use_plugin else None

    host = torch.load(HERE / "models" / "CDDFuse_IVF.pth", map_location=device)
    key_enc = "CDDF_Encoder" if "CDDF_Encoder" in host else "DIDF_Encoder"
    key_dec = "CDDF_Decoder" if "CDDF_Decoder" in host else "DIDF_Decoder"
    Encoder.load_state_dict(host[key_enc])
    Decoder.load_state_dict(host[key_dec])
    BaseFuseLayer.load_state_dict(host["BaseFuseLayer"])
    DetailFuseLayer.load_state_dict(host["DetailFuseLayer"])

    for module in (Encoder, Decoder):
        module.eval()
        for parameter in module.parameters():
            parameter.requires_grad_(False)
    for module in (BaseFuseLayer, DetailFuseLayer):
        module.train()
        for parameter in module.parameters():
            parameter.requires_grad_(True)
    if use_plugin:
        for module in (Plugin_B, Plugin_D):
            module.train()
            for parameter in module.parameters():
                parameter.requires_grad_(True)

    fusion_parameters = list(BaseFuseLayer.parameters()) + list(DetailFuseLayer.parameters())
    groups = [{"params": fusion_parameters, "lr": 1e-5}]
    trainable_parameters = list(fusion_parameters)
    if use_plugin:
        plugin_parameters = list(Plugin_B.parameters()) + list(Plugin_D.parameters())
        groups.append({"params": plugin_parameters, "lr": 1e-4})
        trainable_parameters += plugin_parameters
    optimizer = torch.optim.Adam(groups, weight_decay=0)
    scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size=8, gamma=0.5)
    criteria_fusion = Fusionloss().to(device)
    trainloader = DataLoader(
        H5Dataset(str(HERE / "data" / "MSRS_train_imgsize_128_stride_200.h5")),
        batch_size=2, shuffle=True, num_workers=0,
        generator=torch.Generator().manual_seed(args.seed),
    )
    print(f"trainable_parameters={sum(p.numel() for p in trainable_parameters):,}; "
          f"fusion_lr=1e-5; plugin_lr={'1e-4' if use_plugin else 'none'}", flush=True)

    pattern = str(HERE / "models" / f"CDDFuse_finetune_{run_mode}_seed{args.seed}_*_ep*.pth")
    existing = glob.glob(pattern)
    start_epoch = 0
    timestamp = datetime.datetime.now().strftime("%m-%d-%H-%M")
    if existing:
        latest = max(existing, key=lambda path: (epoch_of(path), os.path.getmtime(path)))
        checkpoint = torch.load(latest, map_location=device)
        BaseFuseLayer.load_state_dict(checkpoint["BaseFuseLayer"])
        DetailFuseLayer.load_state_dict(checkpoint["DetailFuseLayer"])
        if use_plugin:
            Plugin_B.load_state_dict(checkpoint["FourierPlugin"])
            Plugin_D.load_state_dict(checkpoint["FourierPlugin_D"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        scheduler.load_state_dict(checkpoint["scheduler"])
        start_epoch = epoch_of(latest) + 1
        timestamp = checkpoint.get("timestamp", timestamp)
        print(f"resume={os.path.basename(latest)}; start_epoch={start_epoch}", flush=True)

    previous = time.time()
    for epoch in range(start_epoch, args.epochs):
        for index, (data_VIS, data_IR) in enumerate(trainloader):
            if args.max_batches and index >= args.max_batches:
                break
            data_VIS, data_IR = data_VIS.to(device), data_IR.to(device)
            optimizer.zero_grad()
            with torch.no_grad():
                feature_V_B, feature_V_D, _ = Encoder(data_VIS)
                feature_I_B, feature_I_D, _ = Encoder(data_IR)
            if use_plugin:
                fused_B = Plugin_B(feature_I_B, feature_V_B)
                fused_D = Plugin_D(feature_I_D, feature_V_D)
            else:
                fused_B = feature_I_B + feature_V_B
                fused_D = feature_I_D + feature_V_D
            feature_F_B = BaseFuseLayer(fused_B)
            feature_F_D = DetailFuseLayer(fused_D)
            data_Fuse, _ = Decoder(data_VIS, feature_F_B, feature_F_D)
            loss, loss_in, loss_grad = criteria_fusion(data_VIS, data_IR, data_Fuse)
            loss.backward()
            nn.utils.clip_grad_norm_(trainable_parameters, max_norm=0.01, norm_type=2)
            optimizer.step()
            elapsed = time.time() - previous
            previous = time.time()
            batches_done = epoch * len(trainloader) + index
            eta = datetime.timedelta(seconds=(args.epochs * len(trainloader) - batches_done) * elapsed)
            sys.stdout.write(
                f"\r[Epoch {epoch}/{args.epochs}] [Batch {index}/{len(trainloader)}] "
                f"[loss {loss.item():.6f}; in {loss_in.item():.4f}; grad {loss_grad.item():.4f}] ETA: {eta}"
            )
            sys.stdout.flush()

        scheduler.step()
        for group in optimizer.param_groups:
            if group["lr"] <= 1e-6:
                group["lr"] = 1e-6
        peak_gb = torch.cuda.max_memory_allocated() / 1e9 if device == "cuda" else 0.0
        output = HERE / "models" / f"CDDFuse_finetune_{run_mode}_seed{args.seed}_{timestamp}_ep{epoch}.pth"
        checkpoint = {
            "CDDF_Encoder": Encoder.state_dict(),
            "CDDF_Decoder": Decoder.state_dict(),
            "BaseFuseLayer": BaseFuseLayer.state_dict(),
            "DetailFuseLayer": DetailFuseLayer.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(),
            "ab_mode": "full" if use_plugin else "none",
            "cutoff": 0.125,
            "dual_branch": use_plugin,
            "use_plugin": use_plugin,
            "plugin_variant": args.plugin_variant,
            "seed": args.seed,
            "epoch": epoch,
            "timestamp": timestamp,
            "protocol": "frozen_encoder_decoder_finetune_fusion_layers_with_or_without_dual_branch_plugin",
            "max_batches": args.max_batches,
        }
        if use_plugin:
            checkpoint["FourierPlugin"] = Plugin_B.state_dict()
            checkpoint["FourierPlugin_D"] = Plugin_D.state_dict()
        torch.save(checkpoint, output)
        learning_rates = ",".join(f"{group['lr']:.2e}" for group in optimizer.param_groups)
        print(f"\n[epoch {epoch}] saved={output.name}; lr={learning_rates}; peak_gpu={peak_gb:.2f} GB", flush=True)
        if args.max_batches:
            break
    print("FINETUNE_TRAINING_DONE", flush=True)


if __name__ == "__main__":
    main()
