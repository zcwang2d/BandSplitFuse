# -*- coding: utf-8 -*-
"""Sequential controlled experiment queue; safe to rerun after interruption."""
from pathlib import Path
import datetime
import glob
import json
import os
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
OUT = HERE / "controlled_experiments_20261112"
OUT.mkdir(exist_ok=True)
STATUS = OUT / "queue_status.json"
CONFIGS = [
    ("full", 20261112),
    ("amp_only", 20261112),
    ("phase_only", 20261112),
    ("full", 20261113),
    ("full", 20261114),
]


def write_status(state):
    STATUS.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")


def final_checkpoint(mode, seed):
    files = glob.glob(str(HERE / "models" / f"CDDFuse_ctrl_{mode}_seed{seed}_*_ep19.pth"))
    return max(files, key=os.path.getmtime) if files else None


state = {
    "started_at": datetime.datetime.now().isoformat(timespec="seconds"),
    "status": "running",
    "configs": [],
    "note": "Frozen official CDDFuse host; dual-branch plug-ins only; 20 epochs; final-epoch evaluation.",
}
write_status(state)

for mode, seed in CONFIGS:
    tag = f"{mode}_seed{seed}"
    entry = {"tag": tag, "mode": mode, "seed": seed, "status": "running", "started_at": datetime.datetime.now().isoformat(timespec="seconds")}
    state["current"] = tag
    state["configs"] = [x for x in state["configs"] if x["tag"] != tag] + [entry]
    write_status(state)
    train_log = OUT / f"train_{tag}.log"
    test_log = OUT / f"test_{tag}.log"
    checkpoint = final_checkpoint(mode, seed)
    if checkpoint is None:
        with train_log.open("a", encoding="utf-8") as stream:
            stream.write(f"\n\n=== run {datetime.datetime.now().isoformat(timespec='seconds')} ===\n")
            stream.flush()
            result = subprocess.run(
                [sys.executable, "-u", "train_controlled_pnp.py", "--mode", mode, "--seed", str(seed), "--epochs", "20"],
                cwd=HERE, stdout=stream, stderr=subprocess.STDOUT,
            )
        entry["train_returncode"] = result.returncode
        if result.returncode != 0:
            entry["status"] = "failed_training"
            state["status"] = "failed"
            write_status(state)
            sys.exit(result.returncode)
        checkpoint = final_checkpoint(mode, seed)
    if checkpoint is None:
        entry["status"] = "missing_final_checkpoint"
        state["status"] = "failed"
        write_status(state)
        sys.exit(2)

    entry["checkpoint"] = checkpoint
    with test_log.open("w", encoding="utf-8") as stream:
        result = subprocess.run(
            [sys.executable, "-u", "test_IVF_plugin.py", checkpoint, "MSRS,TNO,RoadScene"],
            cwd=HERE, stdout=stream, stderr=subprocess.STDOUT,
        )
    entry["test_returncode"] = result.returncode
    if result.returncode != 0:
        entry["status"] = "failed_testing"
        state["status"] = "failed"
        write_status(state)
        sys.exit(result.returncode)
    entry["status"] = "completed"
    entry["completed_at"] = datetime.datetime.now().isoformat(timespec="seconds")
    state["configs"] = [x for x in state["configs"] if x["tag"] != tag] + [entry]
    write_status(state)

state["status"] = "completed"
state["current"] = None
state["completed_at"] = datetime.datetime.now().isoformat(timespec="seconds")
write_status(state)
print("ALL_CONTROLLED_EXPERIMENTS_DONE", flush=True)
