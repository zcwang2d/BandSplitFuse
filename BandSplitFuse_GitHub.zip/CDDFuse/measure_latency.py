# -*- coding: utf-8 -*-
"""Measure baseline and BandSplitFuse inference latency on random tensors."""
import argparse
import os
import sys
import time

import torch
import torch.nn as nn

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "FourierFuse"))
from fourier_plugin import BandSplitFuse
from net import Restormer_Encoder, Restormer_Decoder, BaseFeatureExtraction, DetailFeatureExtraction
import warnings

warnings.filterwarnings("ignore")
os.environ["CUDA_VISIBLE_DEVICES"] = "0"


def build(device, baseline_ckpt, plugin_ckpt=None):
    encoder = nn.DataParallel(Restormer_Encoder()).to(device)
    decoder = nn.DataParallel(Restormer_Decoder()).to(device)
    base_fuse = nn.DataParallel(BaseFeatureExtraction(dim=64, num_heads=8)).to(device)
    detail_fuse = nn.DataParallel(DetailFeatureExtraction(num_layers=1)).to(device)
    checkpoint = torch.load(baseline_ckpt, map_location=device)
    key_enc = "CDDF_Encoder" if "CDDF_Encoder" in checkpoint else "DIDF_Encoder"
    key_dec = "CDDF_Decoder" if "CDDF_Decoder" in checkpoint else "DIDF_Decoder"
    encoder.load_state_dict(checkpoint[key_enc])
    decoder.load_state_dict(checkpoint[key_dec])
    base_fuse.load_state_dict(checkpoint["BaseFuseLayer"])
    detail_fuse.load_state_dict(checkpoint["DetailFuseLayer"])
    plugin = plugin_d = None
    if plugin_ckpt:
        pck = torch.load(plugin_ckpt, map_location=device)
        plugin = nn.DataParallel(BandSplitFuse(
            dim=64, cutoff=pck.get("cutoff", 0.125), mode=pck.get("ab_mode", "full")
        )).to(device)
        plugin.load_state_dict(pck["FourierPlugin"])
        if pck.get("dual_branch"):
            encoder.load_state_dict(pck["CDDF_Encoder"])
            decoder.load_state_dict(pck["CDDF_Decoder"])
            base_fuse.load_state_dict(pck["BaseFuseLayer"])
            detail_fuse.load_state_dict(pck["DetailFuseLayer"])
            plugin_d = nn.DataParallel(BandSplitFuse(dim=64)).to(device)
            plugin_d.load_state_dict(pck["FourierPlugin_D"])
    modules = [encoder, decoder, base_fuse, detail_fuse, plugin, plugin_d]
    for module in (m for m in modules if m is not None):
        module.eval()
    return modules


def run_once(mods, ir, vi, use_plugin):
    encoder, decoder, base_fuse, detail_fuse, plugin, plugin_d = mods
    feature_v_b, feature_v_d, _ = encoder(vi)
    feature_i_b, feature_i_d, _ = encoder(ir)
    if use_plugin and plugin is not None:
        feature_b_fused = plugin(feature_i_b, feature_v_b)
        if plugin_d is not None:
            feature_f_d = detail_fuse(plugin_d(feature_i_d, feature_v_d))
        else:
            feature_f_d = detail_fuse(feature_v_d + feature_i_d)
    else:
        feature_b_fused = feature_v_b + feature_i_b
        feature_f_d = detail_fuse(feature_v_d + feature_i_d)
    feature_f_b = base_fuse(feature_b_fused)
    data_fuse, _ = decoder(vi, feature_f_b, feature_f_d)
    return data_fuse


def bench(mods, height, width, use_plugin, device, iterations):
    ir = torch.rand(1, 1, height, width, device=device)
    vi = torch.rand(1, 1, height, width, device=device)
    with torch.no_grad():
        for _ in range(5):
            run_once(mods, ir, vi, use_plugin)
        if device == "cuda":
            torch.cuda.synchronize()
        start = time.perf_counter()
        for _ in range(iterations):
            run_once(mods, ir, vi, use_plugin)
        if device == "cuda":
            torch.cuda.synchronize()
    return (time.perf_counter() - start) / iterations * 1000


def count_parameters(modules):
    return sum(sum(p.numel() for p in module.parameters()) for module in modules if module is not None)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("checkpoint", help="BandSplitFuse checkpoint")
    parser.add_argument("--baseline", default="models/CDDFuse_IVF.pth",
                        help="CDDFuse baseline checkpoint")
    parser.add_argument("--iterations", type=int, default=30,
                        help="Timed iterations per resolution")
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu",
                        choices=["cuda", "cpu"])
    return parser.parse_args()


def main():
    args = parse_args()
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA was requested but is not available")
    mods_base = build(args.device, args.baseline)
    mods_full = build(args.device, args.baseline, args.checkpoint)
    print(f"{'Resolution':>12} | {'baseline(ms)':>12} | {'+BandSplitFuse(ms)':>18} | {'overhead':>8}")
    for height, width in [(128, 128), (480, 640)]:
        t_base = bench(mods_base, height, width, False, args.device, args.iterations)
        t_full = bench(mods_full, height, width, True, args.device, args.iterations)
        print(f"{height:>5}x{width:<6} | {t_base:>12.1f} | {t_full:>18.1f} | {(t_full/t_base-1)*100:>7.1f}%")
    n_base = count_parameters(mods_base)
    n_full = count_parameters(mods_full)
    print(f"\nTotal parameters: baseline {n_base:,} -> +plugin {n_full:,} "
          f"(added {n_full-n_base:,}, {(n_full-n_base)/n_base*100:.2f}%)")


if __name__ == "__main__":
    main()
