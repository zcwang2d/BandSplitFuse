# -*- coding: utf-8 -*-
"""Generate CDDFuse and BandSplitFuse images for a labeled MSRS detection subset."""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import time

import numpy as np
from PIL import Image
import torch
import torch.nn as nn

ROOT = Path(__file__).resolve().parents[1]
CDDFUSE = ROOT / "CDDFuse"
DETECTION = ROOT / "MSRS-main" / "detection"
OUTPUT = ROOT / "downstream_detection"
sys.path.insert(0, str(CDDFUSE))
sys.path.insert(0, str(ROOT / "FourierFuse"))

from net import Restormer_Encoder, Restormer_Decoder, BaseFeatureExtraction, DetailFeatureExtraction
from fourier_plugin import BandSplitFuse
from utils.img_read_save import img_save


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_image(path, device):
    # PIL also handles non-ASCII repository paths on Windows.
    array = np.asarray(Image.open(path).convert("L"), dtype=np.float32)
    array = np.round(array)[np.newaxis, np.newaxis, ...] / 255.0
    return torch.from_numpy(array).to(device)


def save_output(tensor, name, output_dir):
    minimum, maximum = torch.min(tensor), torch.max(tensor)
    normalized = (tensor - minimum) / (maximum - minimum).clamp_min(1e-8)
    array = np.squeeze((normalized * 255).cpu().numpy())
    img_save(array, name, str(output_dir))


def make_host(device):
    encoder = nn.DataParallel(Restormer_Encoder()).to(device)
    decoder = nn.DataParallel(Restormer_Decoder()).to(device)
    base_fuse = nn.DataParallel(BaseFeatureExtraction(dim=64, num_heads=8)).to(device)
    detail_fuse = nn.DataParallel(DetailFeatureExtraction(num_layers=1)).to(device)
    baseline_path = CDDFUSE / "models" / "CDDFuse_IVF.pth"
    checkpoint = torch.load(baseline_path, map_location=device)
    encoder_key = "CDDF_Encoder" if "CDDF_Encoder" in checkpoint else "DIDF_Encoder"
    decoder_key = "CDDF_Decoder" if "CDDF_Decoder" in checkpoint else "DIDF_Decoder"
    encoder.load_state_dict(checkpoint[encoder_key])
    decoder.load_state_dict(checkpoint[decoder_key])
    base_fuse.load_state_dict(checkpoint["BaseFuseLayer"])
    detail_fuse.load_state_dict(checkpoint["DetailFuseLayer"])
    return encoder, decoder, base_fuse, detail_fuse


def run_baseline(device, names):
    output_dir = OUTPUT / "fused" / "CDDFuse"
    output_dir.mkdir(parents=True, exist_ok=True)
    encoder, decoder, base_fuse, detail_fuse = make_host(device)
    for module in (encoder, decoder, base_fuse, detail_fuse):
        module.eval()
    with torch.no_grad():
        for index, name in enumerate(names, 1):
            ir = load_image(DETECTION / "ir" / name, device)
            vi = load_image(DETECTION / "vi" / name, device)
            feature_v_b, feature_v_d, _ = encoder(vi)
            feature_i_b, feature_i_d, _ = encoder(ir)
            fused_b = base_fuse(feature_v_b + feature_i_b)
            fused_d = detail_fuse(feature_v_d + feature_i_d)
            fused, _ = decoder(vi, fused_b, fused_d)
            save_output(fused, Path(name).stem, output_dir)
            if index % 20 == 0:
                print(f"CDDFuse: {index}/{len(names)}", flush=True)
    del encoder, decoder, base_fuse, detail_fuse
    if device == "cuda":
        torch.cuda.empty_cache()


def run_ours(device, names, checkpoint_path):
    output_dir = OUTPUT / "fused" / "BandSplitFuse"
    output_dir.mkdir(parents=True, exist_ok=True)
    encoder, decoder, base_fuse, detail_fuse = make_host(device)
    checkpoint = torch.load(checkpoint_path, map_location=device)
    cutoff = checkpoint.get("cutoff", 0.125)
    plugin = nn.DataParallel(BandSplitFuse(dim=64, cutoff=cutoff, mode=checkpoint.get("ab_mode", "full"))).to(device)
    plugin_d = nn.DataParallel(BandSplitFuse(dim=64)).to(device)
    plugin.load_state_dict(checkpoint["FourierPlugin"])
    plugin_d.load_state_dict(checkpoint["FourierPlugin_D"])
    encoder.load_state_dict(checkpoint["CDDF_Encoder"])
    decoder.load_state_dict(checkpoint["CDDF_Decoder"])
    base_fuse.load_state_dict(checkpoint["BaseFuseLayer"])
    detail_fuse.load_state_dict(checkpoint["DetailFuseLayer"])
    for module in (encoder, decoder, base_fuse, detail_fuse, plugin, plugin_d):
        module.eval()
    with torch.no_grad():
        for index, name in enumerate(names, 1):
            ir = load_image(DETECTION / "ir" / name, device)
            vi = load_image(DETECTION / "vi" / name, device)
            feature_v_b, feature_v_d, _ = encoder(vi)
            feature_i_b, feature_i_d, _ = encoder(ir)
            fused_b = base_fuse(plugin(feature_i_b, feature_v_b))
            fused_d = detail_fuse(plugin_d(feature_i_d, feature_v_d))
            fused, _ = decoder(vi, fused_b, fused_d)
            save_output(fused, Path(name).stem, output_dir)
            if index % 20 == 0:
                print(f"BandSplitFuse: {index}/{len(names)}", flush=True)


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True,
                        help="Dual-branch BandSplitFuse checkpoint trained on CDDFuse")
    parser.add_argument("--detection-dir", type=Path, default=DETECTION,
                        help="Directory containing ir/, vi/ and labels/")
    parser.add_argument("--output-dir", type=Path, default=OUTPUT,
                        help="Directory for fused images and metadata")
    parser.add_argument("--expected-count", type=int, default=80,
                        help="Expected image-pair count; use 0 to disable this check")
    return parser.parse_args()


def main():
    global DETECTION, OUTPUT
    args = parse_args()
    DETECTION = args.detection_dir.resolve()
    OUTPUT = args.output_dir.resolve()
    checkpoint_path = args.checkpoint.resolve()
    if not checkpoint_path.is_file():
        raise FileNotFoundError(f"BandSplitFuse checkpoint not found: {checkpoint_path}")
    started = time.time()
    OUTPUT.mkdir(parents=True, exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    names = sorted(path.name for path in (DETECTION / "ir").glob("*.png"))
    if args.expected_count and len(names) != args.expected_count:
        raise ValueError(f"Expected {args.expected_count} labeled images, found {len(names)}")
    if not names:
        raise ValueError(f"No PNG images found in {DETECTION / 'ir'}")
    assert all((DETECTION / "vi" / name).exists() for name in names)
    print(f"device={device}; images={len(names)}", flush=True)
    run_baseline(device, names)
    run_ours(device, names, checkpoint_path)
    baseline_path = CDDFUSE / "models" / "CDDFuse_IVF.pth"
    metadata = {
        "device": device,
        "gpu": torch.cuda.get_device_name(0) if device == "cuda" else None,
        "images": len(names),
        "baseline_checkpoint": str(baseline_path),
        "baseline_sha256": sha256(baseline_path),
        "ours_checkpoint": str(checkpoint_path),
        "ours_sha256": sha256(checkpoint_path),
        "elapsed_seconds": time.time() - started,
        "outputs": {
            method: len(list((OUTPUT / "fused" / method).glob("*.png")))
            for method in ("CDDFuse", "BandSplitFuse")
        },
    }
    (OUTPUT / "fusion_metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")
    print(json.dumps(metadata, indent=2), flush=True)


if __name__ == "__main__":
    main()
