# Runtime validation

Validation dates: 2026-11-08, 2026-11-11, and 2026-11-14.

The release directory was compared byte-for-byte with the Python files used for the runtime checks below. The public package itself remains free of datasets, checkpoints, raw generated outputs, raw logs, and plotting code; only aggregated three-seed CSV tables are included. Test assets were injected only into a separate validation copy. The held-out detection re-evaluation on 2026-11-11 used the original local datasets and saved predictions through command-line arguments, without copying them into the release.

## Environment

- Windows, Python 3.10.22
- PyTorch 2.9.1+cu128, CUDA 12.8
- Kornia 0.8.2
- Ultralytics 8.3.40
- OpenCV 5.0.0
- NVIDIA GeForce RTX 5060 Laptop GPU

## Checks completed

| Workflow | Runtime scope | Result |
|---|---|---|
| Core and fine-tuning variant unit tests | Shape, zero initialization, reliability weights and backward pass; 5 tests | Passed on 2026-11-14 |
| MSRS preprocessing | One real training pair; 6 HDF5 patches generated | Passed |
| CDDFuse baseline training | One epoch and one batch with smoke-test epoch/batch-size overrides | Passed |
| Full BandSplitFuse training | `train_full_plugin.py 2 1`; Phase I and Phase II, one real batch each | Passed |
| Frozen-backbone plugin training | `train_plugin.py 1 1e-4 1` | Passed |
| Ablation training and orchestration | One training batch and one controlled runner configuration | Passed |
| CDDFuse baseline inference | One real pair each from TNO and RoadScene; 8 metrics | Passed |
| BandSplitFuse inference | One real pair each from MSRS, TNO and RoadScene; 8 metrics | Passed |
| Medical fusion inference | One pair each from MRI-CT, MRI-PET and MRI-SPECT, with IVF and MIF weights | Passed |
| DenseFuse plugin training | One real batch with 2 patches | Passed |
| DenseFuse inference | Baseline and trained plugin on one TNO pair | Passed |
| Saved-image metric evaluation | One DenseFuse output; JSON generated | Passed |
| Latency and parameters | Both release resolutions, one timed iteration for smoke testing | Passed |
| Downstream fusion | One labeled pair; CDDFuse and BandSplitFuse outputs generated | Passed |
| YOLOv8n detection | Visible, infrared, CDDFuse and BandSplitFuse inputs; COCO JSON/CSV generated | Passed |
| Held-out MSRS detection | Saved predictions filtered to 23 released test images; 51 annotations; COCOeval rerun | Passed on 2026-11-11 |

The small-sample numerical outputs are smoke-test artifacts only and are not paper results. Full datasets, complete training schedules, and the full controlled-ablation suite were not rerun during this release check. The held-out detection values reproduce the final manuscript protocol: CDDFuse mAP@0.5:0.95 = 0.6642595838533998 and BandSplitFuse = 0.7010948035221104 before rounding.

## Runtime fixes verified

1. `test_MIF.py` now accepts both `CDDF_*` and legacy `DIDF_*` checkpoint keys.
2. DenseFuse plugin training raises a clear error when `drop_last=True` would produce zero training batches.
3. DenseFuse plugin checkpoints are resolved relative to the DenseFuse script directory rather than the CDDFuse data working directory.
4. Saved-image evaluation resolves caller-relative output paths before changing the data working directory.
5. Image decoding uses `np.fromfile` and `cv2.imdecode`, allowing Unicode and non-ASCII repository paths.
6. Baseline training falls back from unavailable `kornia.losses.SSIM` to `SSIMLoss` and prints the selected implementation for protocol transparency.
7. Downstream fusion, detection, and latency scripts accept command-line checkpoint/device arguments instead of relying on local absolute paths or fixed experimental filenames.
8. Held-out detection re-evaluation derives test membership from the released MSRS test partition and does not require new detector inference.
9. `test_IVF_plugin.py` constructs both base and detail plug-ins with the checkpoint's actual ablation mode and cutoff, preventing detail-branch fallback to default `full` settings.

## Final repository checks

- All 36 Python files pass syntax parsing on 2026-11-14.
- All 5 core and fine-tuning variant unit tests pass on 2026-11-14.
- Public-package Python files match the validated copies.
- No plotting/visualization scripts, local absolute paths, datasets, weights, raw logs, manuscripts, or secrets are included.
