# Third-party notices and release checklist

BandSplitFuse incorporates or modifies code from the following research projects. Attribution does not replace permission or license compliance.

## CDDFuse

- Project: **CDDFuse: Correlation-Driven Dual-Branch Feature Decomposition for Multi-Modality Image Fusion**, CVPR 2023.
- Authors: Zixiang Zhao, Haowen Bai, Jiangshe Zhang, Yulun Zhang, Shuang Xu, Zudi Lin, Radu Timofte, and Luc Van Gool.
- Official project page: https://zhaozixiang1228.github.io/Project/CDDFuse/
- Official paper: https://openaccess.thecvf.com/content/CVPR2023/html/Zhao_CDDFuse_Correlation-Driven_Dual-Branch_Feature_Decomposition_for_Multi-Modality_Image_Fusion_CVPR_2023_paper.html
- Source repository identified by the upstream README: https://github.com/Zhaozixiang1228/MMIF-CDDFuse
- Files in this package derived from or retained for CDDFuse compatibility: `CDDFuse/net.py`, `CDDFuse/train.py`, `CDDFuse/test_IVF.py`, `CDDFuse/test_MIF.py`, `CDDFuse/dataprocessing.py`, and `CDDFuse/utils/`.

Please retain the upstream copyright and license notices where required. The local source snapshot did not include a LICENSE file, so no permission is assumed here.

## DenseFuse

- Paper: H. Li and X. J. Wu, **DenseFuse: A Fusion Approach to Infrared and Visible Images**, IEEE Transactions on Image Processing, 28(5), 2614–2623, 2019.
- Paper: https://arxiv.org/abs/1804.08361
- Original project referenced by the implementation README: https://github.com/hli1221/imagefusion_densefuse
- Files in this package: `densefuse_pytorch-master/densefuse_net.py` and BandSplitFuse integration/evaluation scripts.

The local `densefuse_pytorch-master` snapshot did not include a LICENSE file or an unambiguous URL for the exact PyTorch implementation. Confirm its provenance and licensing before redistribution.

## MSRS and other datasets

- MSRS official repository: https://github.com/Linfeng-Tang/MSRS
- TNO, RoadScene, COCO, and detector weights remain subject to their original terms.
- No dataset images, annotations, COCO data, or pretrained weights are redistributed in this package.

## Ultralytics YOLO

The optional downstream evaluation imports `ultralytics` and uses COCO-pretrained YOLOv8n weights. Review the Ultralytics licensing terms and the terms associated with the downloaded weights before public or commercial use.

## Before making the repository public

- [ ] Confirm the exact upstream source and license for every retained third-party file.
- [ ] Restore required copyright/license notices and add an appropriate repository LICENSE only after compatibility is confirmed.
- [ ] Verify that public redistribution of modified CDDFuse/DenseFuse code is permitted.
- [ ] Keep datasets, annotations, checkpoints, and generated outputs out of Git unless their redistribution is explicitly allowed.
- [ ] Add genuine model-release URLs only after the corresponding GitHub Release assets exist.
- [ ] Update citation and DOI fields only after formal publication.
