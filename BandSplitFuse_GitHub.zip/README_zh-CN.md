# BandSplitFuse 中文说明

**BandSplitFuse：用于红外与可见光图像融合的轻量级频域即插即用模块**

[English README](README.md) · [复现说明](REPRODUCIBILITY.md) · [运行验证记录](VALIDATION.md) · [GitHub 上传步骤](UPLOAD_TO_GITHUB.md)

BandSplitFuse 使用径向软掩膜划分低频和高频成分，在低频带进行幅值门控，在高频带进行相位一致性门控，并通过零初始化残差支路保持初始融合行为。仓库提供 CDDFuse 和 DenseFuse 两种骨干网络的接入实现。

本代码包**包含模型、训练、测试、指标评估、消融、效率和下游检测代码，以及三种子配对复验的汇总表，不包含任何绘图或可视化脚本**，也不包含数据集、模型权重、原始实验日志或投稿过程文件。

## 环境安装

建议使用 Python 3.10。先根据显卡和 CUDA 版本安装合适的 PyTorch，再安装其余依赖：

```bash
conda create -n bandsplitfuse python=3.10 -y
conda activate bandsplitfuse
# 先按 https://pytorch.org/get-started/locally/ 安装 torch/torchvision
pip install -r requirements.txt
python -m unittest discover -s tests -v
```

## 数据和权重

从 [MSRS 官方仓库](https://github.com/Linfeng-Tang/MSRS) 获取数据，并按以下结构放置：

```text
CDDFuse/MSRS_train/{ir,vi}/
CDDFuse/test_img/MSRS/{ir,vi}/
CDDFuse/test_img/TNO/{ir,vi}/
CDDFuse/test_img/RoadScene/{ir,vi}/
CDDFuse/models/CDDFuse_IVF.pth
CDDFuse/models/YOUR_BANDSPLITFUSE.pth
densefuse_pytorch-master/train_result/model_weight.pkl
downstream_detection/yolov8n.pt
```

`YOUR_BANDSPLITFUSE.pth` 需要通过本仓库训练得到，或由仓库所有者后续在 Release 中提供。本包没有虚构模型下载链接。

## 训练和测试

### 数据预处理

```bash
cd CDDFuse
python dataprocessing.py
```

### 完整两阶段训练

```bash
python train_full_plugin.py 120 40
```

### 冻结骨干，仅训练插件

```bash
python train_plugin.py 20 1e-4
```

### 融合测试与八项指标

```bash
python test_IVF.py
python test_IVF_plugin.py models/YOUR_BANDSPLITFUSE.pth MSRS,TNO,RoadScene
```

评估指标为 EN、SD、SF、MI、SCD、VIF、Qabf 和 SSIM。

### 受控消融

```bash
python run_ablation.py
```

### 三种子配对微调复验

```bash
python run_continuous_multiseed.py
python summarize_three_seed.py
```

复验在相同 20 轮微调协议下比较无插件基线、原版 BandSplitFuse 和连续频谱路由变体。`results/` 提供逐种子结果及均值 ± 样本标准差，不包含原始日志和权重。连续变体未显示一致的额外优势，因此最终仍保留原版分频带设计；三个种子不构成统计等效性证明。

### 推理延迟和参数量

```bash
python measure_latency.py models/YOUR_BANDSPLITFUSE.pth --baseline models/CDDFuse_IVF.pth
```

### DenseFuse 通用性实验

```bash
cd densefuse_pytorch-master
python train_densefuse_plugin.py 20 1e-4
python test_densefuse.py models/YOUR_DENSEFUSE_PLUGIN.pth MSRS,TNO,RoadScene
```

### 下游零样本检测

先按 `MSRS-main/README.md` 准备检测图像、标签和正式 `MSRS-main/test/vi` 测试划分，再从仓库根目录运行：

```bash
python CDDFuse/run_downstream_fusion.py \
  --checkpoint CDDFuse/models/YOUR_BANDSPLITFUSE.pth \
  --expected-count 80

python downstream_detection/evaluate_detection.py \
  --weights downstream_detection/yolov8n.pt \
  --device 0

python downstream_detection/evaluate_heldout_detection.py \
  --expected-count 23
```

前两条命令生成原始 80 张标注子集的保存预测和 COCO 真实标注；最后一条命令仅保留正式发布 MSRS 测试划分中的 23 张图像，并使用保存预测重新运行 COCOeval，不进行新的推理。论文协议排除 48 张训练划分图像和 9 张不在正式训练／测试划分中的图像，保留子集包含 39 个 person 和 12 个 car 实例。检测器固定为 COCO 预训练 YOLOv8n，不进行微调。该小规模独立测试不应直接解释为完整 MSRS 检测基准结果。

## 复现时必须注意

1. 插件输入顺序固定为 `forward(f_ir, f_vi)`，红外特征在前。
2. BandSplitFuse 完整训练采用 batch size 2，面向 8 GB 显存配置；原始 CDDFuse 基线脚本保留 batch size 8，可按显存调整。
3. 完整训练使用 `SSIMLoss`；基线 `train.py` 优先尝试原始 `SSIM`，当前 Kornia 不提供时回退到 `SSIMLoss`。脚本会打印实际实现，比较时必须保留这一协议差异说明。
4. 旧实验权重、旧日志和未完成的消融结果均已排除；受控消融应使用 `run_ablation.py` 重新生成。
5. 延迟受 GPU、CUDA、PyTorch、分辨率、预热次数和同步方式影响。

## 作者

Zhengwei Wang、Wenzhi Xia、Tao Liu、Xiuhua Zeng  
曲靖师范学院物理与电子工程学院，智能系统与先进材料工程研究中心，云南曲靖 655011

通讯作者：Zhengwei Wang（`wangzw@mail.qjnu.edu.cn`）

## 发布前说明

配套论文仍在审稿中，正式引用和 DOI 应在发表后添加。项目使用了 CDDFuse 和 DenseFuse 代码，公开上传前必须阅读 `THIRD_PARTY_NOTICES.md`，确认上游许可并补充合适的许可证；本包未自动添加 LICENSE。
