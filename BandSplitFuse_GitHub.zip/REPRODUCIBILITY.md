# Reproducibility guide

## 1. Scope

This repository releases executable research code for BandSplitFuse, not the full local experiment workspace. Excluded items include datasets, checkpoints, generated fused images, detection predictions, logs, manuscript files, and all plotting/visualization scripts.

The package supports:

- CDDFuse baseline training and evaluation.
- Full two-stage CDDFuse + BandSplitFuse training.
- Frozen-backbone plugin training.
- Controlled amplitude/phase/cutoff ablation.
- DenseFuse + BandSplitFuse training and evaluation.
- Latency and parameter measurement.
- Fixed YOLOv8n zero-shot detection evaluation.

## 2. Input contract

`BandSplitFuse.forward` expects two tensors with shape `(B, C, H, W)`:

```python
fused = plugin(f_ir, f_vi)
```

The infrared tensor must be first. Both tensors must have identical shapes and be on the same device. The default cutoff is `0.125`; supported ablation modes are `full`, `amp_only`, and `phase_only`.

## 3. Training protocols

### Full CDDFuse + BandSplitFuse

```bash
cd CDDFuse
python train_full_plugin.py 120 40
```

- Two BandSplitFuse modules are inserted into the base and detail branches.
- Phase I covers epochs 0–39 by default; Phase II covers the remaining epochs.
- Batch size is 2 for an 8 GB GPU memory target.
- Checkpoints contain encoder, decoder, both host fusion layers, both plugins, optimizer states, `cutoff`, and `dual_branch=True`.
- The script resumes from the newest matching `models/CDDFuseFULL_*_epN.pth` checkpoint.
- Phase I uses `kornia.losses.SSIMLoss`. The baseline `train.py` tries the original `kornia.losses.SSIM` and falls back to `SSIMLoss` on Kornia versions without `SSIM`; the selected implementation is printed and must be retained in protocol descriptions.
- Schedulers for all modules are stepped throughout this local full-training implementation; this differs from the original CDDFuse scheduler-stepping scope.

### Frozen-backbone plugin training

```bash
python train_plugin.py 20 1e-4
```

The encoder, decoder, base fusion layer, and detail fusion layer are loaded from `models/CDDFuse_IVF.pth` and frozen. Only the base-branch plugin is optimized.

### Controlled ablation

```bash
python run_ablation.py
```

Each configuration starts from the same official baseline, freezes the entire host, trains only the plugin for 20 epochs, uses the original fusion loss and seed `20261108`, and then evaluates on MSRS, TNO, and RoadScene. No controlled-ablation result is bundled; run the script to generate new evidence.

### Three-seed paired fine-tuning

```bash
python run_continuous_multiseed.py
python summarize_three_seed.py
```

- All configurations start from the official pretrained CDDFuse checkpoint and freeze the encoder and decoder.
- The baseline fine-tunes only the base and detail fusion layers for 20 epochs at `1e-5`.
- Each plug-in configuration additionally trains one module instance per branch at `1e-4`.
- Seeds are `20261112`, `20261113`, and `20261114`; the final epoch is evaluated without checkpoint selection.
- `train_fusion_finetune.py` and `test_fusion_finetune.py` implement the matched protocol. `run_continuous_multiseed.py` queues the missing seed 20261113/20261114 runs; the seed 20261112 protocol is identical.
- The continuous alternative is implemented in `FourierFuse/fourier_plugin_continuous.py`; residual/circular diagnostics are retained in `fourier_plugin_residual.py`.
- `results/` contains only aggregated CSV tables and interpretation. Regenerate them with `summarize_three_seed.py` after producing the raw logs. Do not describe three seeds as proof of statistical equivalence.

## 4. Fusion evaluation

```bash
python test_IVF_plugin.py models/YOUR_CHECKPOINT.pth MSRS,TNO,RoadScene
```

Each dataset directory must contain `ir/` and `vi/` with matching filenames. Outputs are saved under `test_result_plugin/`. The following order is used in metric arrays:

```text
EN, SD, SF, MI, SCD, VIF, Qabf, SSIM
```

Images are normalized individually to `[0, 1]` before conversion to 8-bit PNG. Cross-paper comparisons should be treated as descriptive unless data splits, preprocessing, checkpoint selection, and metric implementations are aligned.

## 5. DenseFuse evaluation

The DenseFuse plugin scripts reuse the CDDFuse HDF5 dataset, fusion loss, image utilities, and evaluator. A pretrained DenseFuse autoencoder is required at:

```text
densefuse_pytorch-master/train_result/model_weight.pkl
```

The DenseFuse plugin checkpoint is different from a CDDFuse full checkpoint and must not be interchanged with it.

## 6. Latency protocol

```bash
cd CDDFuse
python measure_latency.py models/YOUR_CHECKPOINT.pth --iterations 30 --device cuda
```

- Resolutions: 128 × 128 and 480 × 640.
- Warmup: 5 iterations per measurement.
- CUDA synchronization is performed before and after timed loops.
- Random tensors are used; no image I/O is included in timing.
- Report hardware, software versions, iteration count, and resolution with all latency results.

## 7. Detection protocol

1. Generate visible, infrared, CDDFuse, and BandSplitFuse inputs with identical filenames.
2. Use the same COCO-pretrained YOLOv8n weights for every method.
3. Do not fine-tune the detector.
4. Keep `imgsz=640`, `conf=0.001`, `iou=0.7`, and `max_det=300` unchanged across methods.
5. Convert YOLO normalized labels to COCO boxes using class IDs 0, 1, and 2 for person, bicycle, and car.
6. Report the exact number of images and annotated instances, and describe the evaluation as a labeled-subset, zero-shot protocol.

The original prediction run used 80 labeled images. For the final manuscript protocol, run `python downstream_detection/evaluate_heldout_detection.py --expected-count 23` after generating `msrs_detection_coco.json` and the saved predictions. This script uses the official `MSRS-main/test/vi` partition to exclude 48 training-partition images and nine images absent from the released train/test partitions. It re-evaluates only the 23 held-out test images (51 annotations: 39 person and 12 car) without new detector inference. Use `--expected-count 0` only for a different subset, and report the resulting split and counts explicitly.

## 8. Current limitations

- No pretrained BandSplitFuse checkpoint is included in this code-only package.
- Controlled ablation must be rerun; no completed controlled-ablation table is claimed here.
- The detection evaluation is limited to a small labeled subset and a fixed off-the-shelf detector.
- Public release requires confirmation of upstream code licenses and dataset licenses.
- A manuscript-under-review citation must not be replaced with an invented DOI or publication status.
